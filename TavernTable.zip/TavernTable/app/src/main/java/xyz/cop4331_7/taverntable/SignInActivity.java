package xyz.cop4331_7.taverntable;

import android.app.AlertDialog;
import android.content.Intent;
//import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SignInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        // Set variable values to the inputs in the Sign Up page.
        final EditText etUsername = (EditText) findViewById(R.id.etUsername);
        final EditText etPassword = (EditText) findViewById(R.id.etPassword);
        final Button bSignIn = (Button) findViewById(R.id.bSignIn);
        final Button bSignup = (Button) findViewById(R.id.bSignUp);

        //configureBackButton();

        // When Sign Up button is clicked, go to the sign up page.
        /*bSignup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent signUpIntent = new Intent(SignInActivity.this, RegisterActivity.class);
                SignInActivity.this.startActivity(signUpIntent);
            }
        });*/

        // When Sign In button is clicked, go to the Sign In page.
        bSignIn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                final String username = etUsername.getText().toString();
                final String password = etPassword.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response)
                    {
                        try
                        {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if(success)
                            {

                                Intent intent = new Intent(SignInActivity.this, UserAreaActivity.class);
                                intent.putExtra("username", username);

                                startActivity(intent);
                            }
                            else
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(SignInActivity.this);
                                builder.setMessage("Login failed.")
                                        .setNegativeButton("Try Again", null)
                                        .create().show();
                            }
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                };

                SignInRequest loginRequest = new SignInRequest(username, password, responseListener);
                RequestQueue queue = Volley.newRequestQueue(SignInActivity.this);
                queue.add(loginRequest);
            }
        });
    }

    /*public void configureBackButton() {
        FloatingActionButton backButton = (FloatingActionButton) findViewById(R.id.signInBackButton);
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }*/
}
