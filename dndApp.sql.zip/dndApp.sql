-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 07, 2018 at 07:02 PM
-- Server version: 5.6.40
-- PHP Version: 7.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dndApp`
--

-- --------------------------------------------------------

--
-- Table structure for table `Abilities`
--

CREATE TABLE `Abilities` (
  `abilityID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `spell` tinyint(1) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `ritual` tinyint(1) NOT NULL DEFAULT '0',
  `castingTime` varchar(15) NOT NULL,
  `range` int(11) DEFAULT NULL,
  `target` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `v` tinyint(1) DEFAULT '0',
  `s` tinyint(1) DEFAULT '0',
  `m` tinyint(1) DEFAULT '0',
  `component` text,
  `concentration` tinyint(1) DEFAULT '0',
  `duration` int(11) DEFAULT NULL,
  `savingThrowAdvantage` varchar(3) DEFAULT NULL,
  `savingThrow` varchar(3) DEFAULT NULL,
  `damageSchool` varchar(20) DEFAULT NULL,
  `damageType` varchar(20) DEFAULT NULL,
  `damageDie` int(11) DEFAULT NULL,
  `successDamage` int(11) DEFAULT NULL,
  `failDamage` int(11) DEFAULT NULL,
  `healDie` int(11) DEFAULT NULL,
  `headRolls` int(11) DEFAULT NULL,
  `description` text,
  `levelUpInfo` text,
  `bardCom` tinyint(1) NOT NULL DEFAULT '0',
  `clericCom` tinyint(1) NOT NULL DEFAULT '0',
  `druidCom` tinyint(1) NOT NULL DEFAULT '0',
  `paladinCom` tinyint(1) NOT NULL DEFAULT '0',
  `rangerCom` tinyint(1) NOT NULL DEFAULT '0',
  `sorcererCom` tinyint(1) NOT NULL DEFAULT '0',
  `warlockCom` tinyint(1) NOT NULL DEFAULT '0',
  `wizardCom` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Abilities`
--

INSERT INTO `Abilities` (`abilityID`, `name`, `spell`, `level`, `ritual`, `castingTime`, `range`, `target`, `area`, `v`, `s`, `m`, `component`, `concentration`, `duration`, `savingThrowAdvantage`, `savingThrow`, `damageSchool`, `damageType`, `damageDie`, `successDamage`, `failDamage`, `healDie`, `headRolls`, `description`, `levelUpInfo`, `bardCom`, `clericCom`, `druidCom`, `paladinCom`, `rangerCom`, `sorcererCom`, `warlockCom`, `wizardCom`) VALUES
(1, 'Acid Splash', 1, 0, 0, '1 action', 60, -1, -1, 1, 1, 0, '', 0, 0, '', 'Dex', 'Conjuration', 'Acid', 1, 1, 0, 0, 0, 'You hurl a bubble of acid. Choose one creature within range, or choose two creatures within range that are within 5 feet of each other. A target must succeed on a Dexterity saving throw or take 1d6 acid damage.', 'This spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).', 0, 0, 0, 0, 0, 1, 0, 1),
(2, 'Aid', 1, 2, 0, '1 action', 30, 3, -1, 1, 1, 1, 'white cloth strip', 0, 8, '', '', 'Abjuration', 'Buff', 0, 0, 0, 0, 0, 'Your spell bolsters your allies with toughness and resolve. Choose up to three creatures within range. Each target\'s hit point maximum and current hit points increase by 5 for the duration.', 'When you cast this spell using a spell slot of 3rd level or higher, a target\'s hit points increase by an additional 5 for each slot level above 2nd.', 0, 1, 0, 1, 0, 0, 0, 0),
(3, 'Alarm', 1, 1, 1, '1 minute', 30, -1, -1, 1, 1, 1, 'tiny bell, silver wire', 0, 8, '', '', 'Abjuration', 'Detection', 0, 0, 0, 0, 0, 'You set an alarm against unwanted intrusion. Choose a door, a window, or an area within range that is no larger than a 20-foot cube. Until the spell ends, an alarm alerts you whenever a Tiny or larger creature touches or enters the warded area. When you cast the spell, you can designate creatures that won\'t set off the alarm. You also choose whether the alarm is mental or audible. A mental alarm alerts you with a ping in your mind if you are within 1 mile of the warded area. This ping awakens you if you are sleeping. An audible alarm produces the sound of a hand bell for 10 seconds within 60 feet.\r\n\r\n', '', 0, 0, 0, 0, 1, 0, 0, 1),
(4, 'Alter Self', 1, 2, 0, '1 action', 0, 1, 0, 1, 1, 0, '', 1, 1, '', '', 'Transmutation', 'Shapechanging', 0, 0, 0, 0, 0, 'ou assume a different form. When you cast the spell, choose one of the following options, the effects of which last for the duration of the spell. While the spell lasts, you can end one option as an action to gain the benefits of a different one. Aquatic Adaptation. You adapt your body to an aquatic environment, sprouting gills and growing webbing between your fingers. You can breathe underwater and gain a swimming speed equal to your walking speed. Change Appearance. You transform your appearance. You decide what you look like, including your height, weight, facial features, sound of your voice, hair length, coloration, and distinguishing characteristics, if any. You can make yourself appear as a member of another race, though none of your statistics change. You also can\'t appear as a creature of a different size than you, and your basic shape stays the same; if you\'re bipedal, you can\'t use this spell to become quadrupedal, for instance. At any time for the duration of the spell, you can use your action to change your appearance in this way again. Natural Weapons. You grow claws, fangs, spines, horns, or a different natural weapon of your choice. Your unarmed strikes deal 1d6 bludgeoning, piercing, or slashing damage, as appropriate to the natural weapon you chose, and you are proficient with your unarmed strikes. Finally, the natural weapon is magic and you have a +1 bonus to the attack and damage rolls you make using it.', '', 0, 0, 0, 0, 0, 1, 0, 1),
(5, 'Animal Friendship', 1, 1, 0, '1 action', 30, 1, 30, 1, 1, 1, 'morsel of food', 0, 24, '', 'WIS', 'Enchantment', 'Charmed', 0, 0, 0, 0, 0, 'This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast\'s Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell\'s duration. If you or one of your companions harms the target, the spells ends.', 'When you cast this spell using a spell slot of 2nd level or higher, you can affect one additional beast level above 1st.', 1, 1, 1, 0, 1, 0, 0, 0),
(6, 'Animal Messenger', 1, 2, 1, '1 action', 30, 1, 30, 1, 1, 1, 'morsel of food', 0, 24, '', '', 'Enchantment', 'Communication', 0, 0, 0, 0, 0, 'By means of this spell, you use an animal to deliver a message. Choose a Tiny beast you can see within range, such as a squirrel, a blue jay, or a bat. You specify a location, which you must have visited, and a recipient who matches a general description, such as \"a man or woman dressed in the uniform of the town guard\" or \"a red-haired dwarf wearing a pointed hat.\" You also speak a message of up to twenty-five words. The target beast travels for the duration of the spell toward the specified location, covering about 50 miles per 24 hours for a flying messenger, or 25 miles for other animals. When the messenger arrives, it delivers your message to the creature that you described, replicating the sound of your voice. The messenger speaks only to a creature matching the description you gave. If the messenger doesn\'t reach its destination before the spell ends, the message is lost, and the beast makes its way back to where you cast this spell.', 'If you cast this spell using a spell slot of 3rd level or higher, the duration of the spell increases by 48 hours for each slot level above 2nd.', 1, 0, 1, 0, 1, 0, 0, 0),
(7, 'Animal Shapes', 1, 8, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 1, 24, '', '', '', '', 0, 0, 0, 0, 0, 'Your magic turns others into beasts. Choose any number of willing creatures that you can see within range. You transform each target into the form of a Large or smaller beast with a challenge rating of 4 or lower. On subsequent turns, you can use your action to transform affected creatures into new forms. The transformation lasts for the duration for each target, or until the target drops to 0 hit points or dies. You can choose a different form for each target. A target\'s game statistics are replaced by the statistics of the chosen beast, though the target retains its alignment and Intelligence, Wisdom, and Charisma scores. The target assumes the hit points of its new form, and when it reverts to its normal form, it returns to the number of hit points it had before it transformed. If it reverts as a result of dropping to 0 hit points, any excess damage carries over to its normal form. As long as the excess damage doesn\'t reduce the creature\'s normal form to 0 hit points, it isn\'t knocked unconscious. The creature is limited in the actions it can perform by the nature of its new form, and it can\'t speak or cast spells. The target\'s gear melds into the new form. The target can\'t activate, wield, or otherwise benefit from any of its equipment.', '', 0, 0, 1, 0, 0, 0, 0, 0),
(8, 'Animate Dead', 1, 3, 0, '1 minute', 10, 0, 0, 1, 1, 1, 'blood, flesh, bone', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, 'This spell creates an undead servant. Choose a pile of bones or a corpse of a Medium or Small humanoid within range. Your spell imbues the target with a foul mimicry of life, raising it as an undead creature. The target becomes a skeleton if you chose bones or a zombie if you chose a corpse (the GM has the creature\'s game statistics). On each of your turns, you can use a bonus action to mentally command any creature you made with this spell if the creature is within 60 feet of you (if you control multiple creatures, you can command any or all of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move during its next turn, or you can issue a general command, such as to guard a particular chamber or corridor. If you issue no commands, the creature only defends itself against hostile creatures. Once given an order, the creature continues to follow it until its task is complete. The creature is under your control for 24 hours, after which it stops obeying any command you\'ve given it. To maintain control of the creature for another 24 hours, you must cast this spell on the creature again before the current 24-hour period ends. This use of the spell reasserts your control over up to four creatures you have animated with this spell, rather than animating a new one.', 'When you cast this spell using a spell slot of 4th level or higher, you animate or reassert control over two additional undead creatures for each slot level above 3rd. Each of the creatures must come from a different corpse or pile of bones.', 0, 1, 0, 1, 0, 0, 0, 1),
(9, 'Animate Objects', 1, 5, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, 'bjects come to life at your command. Choose up to ten nonmagical objects within range that are not being worn or carried. Medium targets count as two objects, Large targets count as four objects, Huge targets count as eight objects. You can\'t animate any object larger than Huge. Each target animates and becomes a creature under your control until the spell ends or until reduced to 0 hit points. As a bonus action, you can mentally command any creature you made with this spell if the creature is within 500 feet of you (if you control multiple creatures, you can command any or all of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move during its next turn, or you can issue a general command, such as to guard a particular chamber or corridor. If you issue no commands, the creature only defends itself against hostile creatures. Once given an order, the creature continues to follow it until its task is complete.', '', 1, 0, 0, 0, 0, 1, 0, 1),
(10, 'Antilife Shell', 1, 5, 0, '1 action', 10, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, 'A shimmering barrier extends out from you in a 10- foot radius and moves with you, remaining centered on you and hedging out creatures other than undead and constructs. The barrier lasts for the duration. The barrier prevents an affected creature from passing or reaching through. An affected creature can cast spells or make attacks with ranged or reach weapons through the barrier. If you move so that an affected creature is forced to pass through the barrier, the spell ends.', '', 0, 1, 1, 0, 0, 0, 0, 0),
(11, 'Arcane Eye', 1, 4, 0, '1 action', 30, 0, 0, 1, 1, 1, 'a bit of bat fur', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, 'You create an invisible, magical eye within range that hovers in the air for the duration. You mentally receive visual information from the eye, which has normal vision and darkvision out to 30 feet. The eye can look in every direction. As an action, you can move the eye up to 30 feet in any direction. There is no limit to how far away from you the eye can move, but it can\'t enter another plane of existence. A solid barrier blocks the eye\'s movement, but the eye can pass through an opening as small as 1 inch in diameter.', '', 0, 1, 0, 0, 0, 0, 0, 1),
(12, 'Arcane Lock', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'GOLD DUST', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(13, 'Armor of Agathys', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'cup of water', 0, 1, '', '', '', 'Cold', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 0),
(14, 'Arms of Hadar', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 0),
(15, 'Astral Projection', 1, 9, 0, '1 hour', 10, 0, 0, 1, 1, 1, 'JACINTH(1k), SILVER(100)', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 1, 1),
(16, 'Augury', 1, 2, 1, '1 minute', 0, 0, 0, 1, 1, 1, 'special tokens', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(17, 'Aura of Life', 1, 4, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(18, 'Aura of Purity', 1, 4, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(19, 'Aura of Vitality', 1, 3, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(20, 'Awaken', 1, 5, 0, '8 hours', 0, 0, 0, 1, 1, 1, 'AGATE', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 0, 0),
(21, 'Bane', 1, 1, 0, '1 action', 30, 0, 0, 1, 1, 1, 'drop of blood', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 1, 0, 0, 0, 0),
(22, 'Banishing Smite', 1, 5, 0, '1 bonus action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', 'Force', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(23, 'Banishment', 1, 4, 0, '1 action', 60, 0, 0, 1, 1, 1, 'item disliked by target', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 1, 1, 1),
(24, 'Barkskin', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'oak bark', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 1, 0, 0, 0),
(25, 'Beacon of Hope', 1, 3, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(26, 'Beast Sense', 1, 2, 1, '1 action', 0, 0, 0, 0, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 1, 0, 0, 0),
(27, 'Bestow Curse', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 1, 0, 0, 0, 1),
(28, 'Bigby\'s Hand', 1, 5, 0, '1 action', 120, 0, 0, 1, 1, 1, 'eggshell, snakeskin glove', 1, 1, '', '', '', 'Force', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(29, 'Blade Barrier', 1, 6, 0, '1 action', 90, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', 'Slashing', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(30, 'Blade Ward', 1, 0, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(31, 'Bless', 1, 1, 0, '1 action', 30, 0, 0, 1, 1, 1, 'sprinkling of holy water', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(32, 'Blight', 1, 4, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 1, 0, 1, 1, 1),
(33, 'Blinding Smite', 1, 3, 0, '1 bonus action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', 'Radiant', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(34, 'Blindness/Deafness', 1, 2, 0, '1 action', 30, 0, 0, 1, 0, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 1, 0, 1),
(35, 'Blink', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 1, 0, 1),
(36, 'Blur', 1, 2, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 1, 0, 1),
(37, 'Branding Smite', 1, 2, 0, '1 bonus action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', 'Radiant', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(38, 'Burning Hands', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 1, 0, 1),
(39, 'Call Lightning', 1, 3, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', 'Lightning', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(40, 'Calm Emotions', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 0, 0, 0),
(41, 'Chain Lightning', 1, 6, 0, '1 action', 150, 0, 0, 1, 1, 1, 'bit of fur,glass,3 silver pins', 0, 0, '', '', '', 'Lightning', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(42, 'Charm Person', 1, 1, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 1, 1, 1),
(43, 'Chill Touch', 1, 0, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 1, 1, 1),
(44, 'Chromatic Orb', 1, 1, 0, '1 action', 90, 0, 0, 1, 1, 1, 'diamond', 0, 0, '', '', '', 'See Details', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(45, 'Circle of Death', 1, 6, 0, '1 action', 150, 0, 0, 1, 1, 1, 'crushed black pearl', 0, 0, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 1, 1),
(46, 'Circle of Power', 1, 5, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(47, 'Clairvoyance', 1, 3, 0, '10 minutes', 1, 0, 0, 1, 1, 1, 'jeweled horn or glass eye', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 1, 0, 1),
(48, 'Clone', 1, 8, 0, '1 hour', 0, 0, 0, 1, 1, 1, 'See Sourcebook.', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(49, 'Cloud of Daggers', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 1, 'sliver of glass', 1, 1, '', '', '', 'Slashing', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(50, 'Cloudkill', 1, 5, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', 'Poison', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 1, 0, 1),
(51, 'Color Spray', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'pinch of colored powder', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(52, 'Command', 1, 1, 0, '1 action', 60, 0, 0, 1, 0, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(53, 'Commune', 1, 5, 1, '1 minute', 0, 0, 0, 1, 1, 1, 'incense, vial of holy water', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(54, 'Commune with Nature', 1, 5, 1, '1 minute', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 1, 1, 0, 0, 0),
(55, 'Compelled Duel', 1, 1, 0, '1 bonus action', 30, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(56, 'Comprehend Languages', 1, 1, 1, '1 action', 0, 0, 0, 1, 1, 1, 'pinch of soot and salt', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(57, 'Compulsion', 1, 4, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 0),
(58, 'Cone of Cold', 1, 5, 0, '1 action', 0, 0, 0, 1, 1, 1, 'crystal or glass cone', 0, 0, '', '', '', 'Cold', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 1, 0, 1),
(59, 'Confusion', 1, 4, 0, '1 action', 90, 0, 0, 1, 1, 1, '3 nut shells', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 0, 1, 0, 1),
(60, 'Conjure Animals', 1, 3, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 1, 0, 0, 0),
(61, 'Conjure Barrage', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 1, 'ammo or thrown weapon', 0, 0, '', '', '', 'See Details', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 1, 0, 0, 0),
(62, 'Conjure Celestial', 1, 7, 0, '1 minute', 90, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(63, 'Conjure Elemental', 1, 5, 0, '1 minute', 90, 0, 0, 1, 1, 1, 'See Sourcebook', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 1),
(64, 'Conjure Fey', 1, 6, 0, '1 minute', 90, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 1, 0),
(65, 'Conjure Minor Elementals', 1, 4, 0, '1 minute', 90, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 1),
(66, 'Conjure Volley', 1, 5, 0, '1 action', 150, 0, 0, 1, 1, 1, 'ammo or thrown weapon', 0, 0, '', '', '', 'See Details', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 1, 0, 0, 0),
(67, 'Conjure Woodland Beings', 1, 4, 0, '1 action', 60, 0, 0, 1, 1, 1, '1 holly berry per creature', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 1, 0, 0, 0),
(68, 'Contact Other Plane', 1, 5, 1, '1 minute', 0, 0, 0, 1, 0, 0, '', 0, 1, '', '', '', 'Psychic', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 1),
(69, 'Contagion', 1, 5, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 7, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 1, 0, 0, 0, 0),
(70, 'Contingency', 1, 6, 0, '10 minutes', 0, 0, 0, 1, 1, 1, 'ivory statue of self', 0, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(71, 'Continual Flame', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'RUBY DUST', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 1),
(72, 'Control Water', 1, 4, 0, '1 action', 300, 0, 0, 1, 1, 1, 'water drop, pinch of dust', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 1),
(73, 'Control Weather', 1, 8, 0, '10 minutes', 0, 0, 0, 1, 1, 1, 'incense, earth&wood in water', 1, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 1),
(74, 'Cordon of Arrows', 1, 2, 0, '1 action', 5, 0, 0, 1, 1, 1, '4 pieces of ammo', 0, 8, '', '', '', 'Piercing', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 1, 0, 0, 0),
(75, 'Counterspell', 1, 3, 0, '1 reaction (spe', 60, 0, 0, 0, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 1, 1),
(76, 'Create Food and Water', 1, 3, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 1, 0, 0, 0, 0),
(77, 'Create or Destroy Water', 1, 1, 0, '1 action', 30, 0, 0, 1, 1, 1, 'drop of water/sand', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(78, 'Create Undead', 1, 6, 0, '1 minute', 10, 0, 0, 1, 1, 1, 'See Sourcebook.', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 1, 1),
(79, 'Creation', 1, 5, 0, '1 minute', 30, 0, 0, 1, 1, 1, 'bit of matter you want to make', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(80, 'Crown of Madness', 1, 2, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 1, 0, 1, 1, 1),
(81, 'Crusader\'s Mantle', 1, 3, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(82, 'Cure Wounds', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 1, 0, 0, 0),
(83, 'Dancing Lights', 1, 0, 0, '1 action', 120, 0, 0, 1, 1, 1, 'phosphorous or glowworm', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 0, 1),
(84, 'Darkness', 1, 2, 0, '1 action', 60, 0, 0, 1, 0, 1, 'bat fur and pitch or coal', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 1, 0, 1, 1, 1),
(85, 'Darkvision', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'dried carrot or agate', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 1, 1, 0, 1),
(86, 'Daylight', 1, 3, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 1, 1, 1, 0, 0),
(87, 'Death Ward', 1, 4, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(88, 'Delayed Blast Fireball', 1, 7, 0, '1 action', 150, 0, 0, 1, 1, 1, 'tiny ball of guano and sulfur', 1, 1, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(89, 'Demiplane', 1, 8, 0, '1 action', 60, 0, 0, 0, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 1),
(90, 'Destructive Wave', 1, 5, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', 'See Details', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(91, 'Detect Evil and Good', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(92, 'Detect Magic', 1, 1, 1, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 1, 1, 0, 1),
(93, 'Detect Poison and Disease', 1, 1, 1, '1 action', 0, 0, 0, 1, 1, 1, 'yew leaf', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 1, 1, 0, 0, 0),
(94, 'Detect Thoughts', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'a copper piece', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 0, 1),
(95, 'Dimension Door', 1, 4, 0, '1 action', 500, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 1, 0, 1, 1, 1),
(96, 'Disguise Self', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 1, 0, 1),
(97, 'Disintegrate', 1, 6, 0, '1 action', 60, 0, 0, 1, 1, 1, 'lodestone and pinch of dust', 0, 0, '', '', '', 'Force', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(98, 'Dispel Evil and Good', 1, 5, 0, '1 action', 0, 0, 0, 1, 1, 1, 'holy water or silver/iron powder', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(99, 'Dispel Magic', 1, 3, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 0, 1, 1, 1),
(100, 'Dissonant Whispers', 1, 1, 0, '1 action', 60, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', 'Psychic', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 0),
(101, 'Divination', 1, 4, 1, '1 action', 0, 0, 0, 1, 1, 1, 'INCENSE, SAC. OFFERING', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(102, 'Divine Favor', 1, 1, 0, '1 bonus action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(103, 'Divine Word', 1, 7, 0, '1 bonus action', 30, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(104, 'Dominate Beast', 1, 4, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 1, 0, 0),
(105, 'Dominate Monster', 1, 8, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(106, 'Dominate Person', 1, 5, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 1, 0, 1, 0, 1),
(107, 'Drawmij\'s Instant Summons', 1, 6, 1, '1 minute', 0, 0, 0, 1, 1, 1, 'sapphire', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(108, 'Dream', 1, 5, 0, '1 minute', 0, 0, 0, 1, 1, 1, 'sand,ink,quill from asleep bird', 0, 8, '', '', '', 'See Sourcebook.', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 1, 1),
(109, 'Druidcraft', 1, 0, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(110, 'Earthquake', 1, 8, 0, '1 action', 500, 0, 0, 1, 1, 1, 'piece of dirt, rock, and clay', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 1, 0, 0),
(111, 'Eldritch Blast', 1, 0, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Force', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 0),
(112, 'Elemental Weapon', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(113, 'Enhance Ability', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'fur or feather from a beast', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 1, 0, 0),
(114, 'Enlarge/Reduce', 1, 2, 0, '1 action', 30, 0, 0, 1, 1, 1, 'powdered iron', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(115, 'Ensnaring Strike', 1, 1, 0, '1 bonus action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', 'Piercing', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 1, 0, 0, 0),
(116, 'Entangle', 1, 1, 0, '1 action', 90, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 0),
(117, 'Enthrall', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 1, 0),
(118, 'Etherealness', 1, 7, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 1, 1, 1),
(119, 'Evard\'s Black Tentacles', 1, 4, 0, '1 action', 90, 0, 0, 1, 1, 1, 'piece of octopus temtacle', 1, 1, '', '', '', 'Bludgeoning', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(120, 'Expeditious Retreat', 1, 1, 0, '1 bonus action', 0, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 1, 1),
(121, 'Eyebite', 1, 6, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(122, 'Fabricate', 1, 4, 0, '10 minutes', 120, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(123, 'Faerie Fire', 1, 1, 0, '1 action', 60, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 0, 0, 0),
(124, 'False Life', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'alcohol or distilled spirits', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 1, 0, 1),
(125, 'Fear', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 1, 'white feather or hen heart', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(126, 'Feather Fall', 1, 1, 0, '1 reaction ', 60, 0, 0, 1, 0, 1, 'small feather or piece of down', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 0, 1),
(127, 'Feeblemind', 1, 8, 0, '1 action', 150, 0, 0, 1, 1, 1, 'clay,crystal,or mineral spheres', 0, 0, '', '', '', 'Psychic', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 1, 1),
(128, 'Feign Death', 1, 3, 1, '1 action', 0, 0, 0, 1, 1, 1, 'pinch of graveyard dirt', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 0, 0, 1),
(129, 'Find Familiar', 1, 1, 1, '1 hour', 10, 0, 0, 1, 1, 1, 'CHARCOAL,INCENSE,HERBS', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(130, 'Find Steed', 1, 2, 0, '10 minutes', 30, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 0, 0),
(131, 'Find the Path', 1, 6, 0, '1 minute', 0, 0, 0, 1, 1, 1, 'diviner tools,object from target', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 0, 0, 0),
(132, 'Find Traps', 1, 2, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 1, 0, 0, 0),
(133, 'Finger of Death', 1, 7, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 1, 1),
(134, 'Fire Bolt', 1, 0, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(135, 'Fire Shield', 1, 4, 0, '1 action', 0, 0, 0, 1, 1, 1, 'bit of phosphorous or a firefly', 0, 10, '', '', '', 'Fire/Cold', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(136, 'Fire Storm', 1, 7, 0, '1 action', 150, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(137, 'Fireball', 1, 3, 0, '1 action', 150, 0, 0, 1, 1, 1, 'tiny ball of guano and sulfur', 0, 0, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 1, 0, 1),
(138, 'Flame Blade', 1, 2, 0, '1 bonus action', 0, 0, 0, 1, 1, 1, 'sumac leaf', 1, 10, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 0),
(139, 'Flame Strike', 1, 5, 0, '1 action', 60, 0, 0, 1, 1, 1, 'pinch of sulfur', 0, 0, '', '', '', 'Fire + Radiant', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(140, 'Flaming Sphere', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 1, 'tallow,brimstone,iron powder', 1, 1, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 1),
(141, 'Flesh to Stone', 1, 6, 0, '1 action', 60, 0, 0, 1, 1, 1, 'pinch of lime, water, and earth', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 1),
(142, 'Fly', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 1, 'bird\'s wing feather', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 1, 1),
(143, 'Fog Cloud', 1, 1, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 1, 1, 0, 1),
(144, 'Forbiddance', 1, 6, 1, '10 minutes', 0, 0, 0, 1, 1, 1, 'holy water,incense,ruby powder', 0, 1, '', '', '', 'Radiant or Necrotic', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(145, 'Forcecage', 1, 7, 0, '1 action', 100, 0, 0, 1, 1, 1, 'ruby dust', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 1, 1),
(146, 'Foresight', 1, 9, 0, '1 minute', 0, 0, 0, 1, 1, 1, 'hummingbird feather', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 1, 1),
(147, 'Freedom of Movement', 1, 4, 0, '1 action', 0, 0, 0, 1, 1, 1, 'leather strap around arm', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 1, 0, 0, 0),
(148, 'Friends', 1, 0, 0, '1 action', 0, 0, 0, 0, 1, 1, 'makeup applied to face', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(149, 'Gaseous Form', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 1, 'bit of gauze and wisp of smoke', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 1, 1, 1),
(150, 'Gate', 1, 9, 0, '1 action', 60, 0, 0, 1, 1, 1, 'diamond', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 1, 0, 1),
(151, 'Geas', 1, 5, 0, '1 minute', 60, 0, 0, 1, 0, 0, '', 0, 30, '', '', '', 'See Details.', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 0, 0, 0, 1),
(152, 'Gentle Repose', 1, 2, 1, '1 action', 0, 0, 0, 1, 1, 1, 'salt and 1 cp on each eye', 0, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 1),
(153, 'Giant Insect', 1, 4, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 0),
(154, 'Glibness', 1, 8, 0, '1 action', 0, 0, 0, 1, 0, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 1, 0),
(155, 'Globe of Invulnerability', 1, 6, 0, '1 action', 0, 0, 0, 1, 1, 1, 'glass or crystal bead', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(156, 'Glyph of Warding', 1, 3, 0, '1 hour', 0, 0, 0, 1, 1, 1, 'incense, DIAMOND POWDER', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 0, 0, 1),
(157, 'Goodberry', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'sprig of mistletoe', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 1, 0, 0, 0),
(158, 'Grasping Vine', 1, 4, 0, '1 bonus action', 30, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 1, 0, 0, 0),
(159, 'Grease', 1, 1, 0, '1 action', 60, 0, 0, 1, 1, 1, 'pork rind or butter', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(160, 'Greater Invisibility', 1, 4, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 1, 0, 1),
(161, 'Greater Restoration', 1, 5, 0, '1 action', 0, 0, 0, 1, 1, 1, 'DIAMOND DUST', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 0, 0, 0),
(162, 'Guardian of Faith', 1, 4, 0, '1 action', 30, 0, 0, 1, 0, 0, '', 0, 8, '', '', '', 'Radiant', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(163, 'Guards and Wards', 1, 6, 0, '10 minutes', 0, 0, 0, 1, 1, 1, 'See sourcebook.', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(164, 'Guidance', 1, 0, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(165, 'Guiding Bolt', 1, 1, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', 'Radiant', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(166, 'Gust of Wind', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'a legume seed', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 1, 0, 1),
(167, 'Hail of Thorns', 1, 1, 0, '1 bonus action', 0, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', 'Piercing', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 1, 0, 0, 0),
(168, 'Hallow', 1, 5, 0, '24 hours', 0, 0, 0, 1, 1, 1, 'HERBS, OIL, INCENSE', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(169, 'Hallucinatory Terrain', 1, 4, 0, '10 minutes', 300, 0, 0, 1, 1, 1, 'stone, twig, bit of green plant', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 1, 1),
(170, 'Harm', 1, 6, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(171, 'Haste', 1, 3, 0, '1 action', 30, 0, 0, 1, 1, 1, 'shaving of licorice root', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 1, 0, 1, 0, 1),
(172, 'Heal', 1, 6, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(173, 'Healing Word', 1, 1, 0, '1 bonus action', 60, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 0, 0, 0),
(174, 'Heat Metal', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 1, 'piece of iron and a flame', 1, 1, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 0, 0),
(175, 'Hellish Rebuke', 1, 1, 0, '1 reaction (tak', 60, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 0, 0, 1, 0),
(176, 'Heroes\' Feast', 1, 6, 0, '10 minutes', 30, 0, 0, 1, 1, 1, 'GEM--ENCRUSTED BOWL', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(177, 'Heroism', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 1, 0, 0, 0, 0),
(178, 'Hex', 1, 1, 0, '1 bonus action', 90, 0, 0, 1, 1, 1, 'petrified eye of a newt', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 0),
(179, 'Hold Monster', 1, 5, 0, '1 action', 90, 0, 0, 1, 1, 1, 'small straight piece of iron', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 1, 0, 1, 1, 1),
(180, 'Hold Person', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 1, 'small straight piece of iron', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 0, 1, 1, 1),
(181, 'Holy Aura', 1, 8, 0, '1 action', 0, 0, 0, 1, 1, 1, 'reliquary containing sacred relic', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(182, 'Hunger of Hadar', 1, 3, 0, '1 action', 150, 0, 0, 1, 1, 1, 'pickled octopus tentacle', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 0),
(183, 'Hunter\'s Mark', 1, 1, 0, '1 bonus action', 90, 0, 0, 1, 0, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 1, 1, 0, 0, 0),
(184, 'Hypnotic Pattern', 1, 3, 0, '1 action', 120, 0, 0, 0, 1, 1, 'glowing stick of incense', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(185, 'Ice Storm', 1, 4, 0, '1 action', 300, 0, 0, 1, 1, 1, 'pinch of dust, drop of water', 0, 0, '', '', '', 'Bludgeoning+Cold', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 1, 0, 1, 0, 1),
(186, 'Identify', 1, 1, 1, '1 minute', 0, 0, 0, 1, 1, 1, 'pearl, owl feather', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 0, 0, 1),
(187, 'Illusory Script', 1, 1, 1, '1 minute', 0, 0, 0, 0, 1, 1, 'LEAD-BASED INK', 0, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 1, 1),
(188, 'Imprisonment', 1, 9, 0, '1 minute', 30, 0, 0, 1, 1, 1, 'See Sourcebook.', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 1, 1),
(189, 'Incendiary Cloud', 1, 8, 0, '1 action', 150, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', 'Fire', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(190, 'Inflict Wounds', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Necrotic', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 0),
(191, 'Insect Plague', 1, 5, 0, '1 action', 300, 0, 0, 1, 1, 1, 'bit of sugar, grain, and fat', 1, 10, '', '', '', 'Piercing', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 1, 0, 0),
(192, 'Invisibility', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'eyelash in gum arabic', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 1, 1, 1),
(193, 'Jump', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'grasshopper\'s hind leg', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 1, 1, 0, 1),
(194, 'Knock', 1, 2, 0, '1 action', 60, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 0, 1),
(195, 'Legend Lore', 1, 5, 0, '10 minutes', 0, 0, 0, 1, 1, 1, 'INCENSE(250),4 ivory strips(50)', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 0, 0, 1),
(196, 'Leomund\'s Secret Chest', 1, 4, 0, '1 action', 0, 0, 0, 1, 1, 1, 'chest(5000), replica chest(50)', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(197, 'Leomund\'s Tiny Hut', 1, 3, 1, '1 minute', 0, 0, 0, 1, 1, 1, 'small crystal bead', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(198, 'Lesser Restoration', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 1, 0, 0, 0),
(199, 'Levitate', 1, 2, 0, '1 action', 60, 0, 0, 1, 1, 1, 'small leather loop or golden wire', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(200, 'Light', 1, 0, 0, '1 action', 0, 0, 0, 1, 0, 1, 'firefly or phosphorescent moss', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 0, 0, 1),
(201, 'Lightning Arrow', 1, 3, 0, '1 bonus action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', 'Lightning', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 1, 1, 0, 0),
(202, 'Lightning Bolt', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 1, 'bit of fur and glass rod', 0, 0, '', '', '', 'LIghtning', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 1, 0, 1),
(203, 'Locate Animals or Plants', 1, 2, 1, '1 action', 0, 0, 0, 1, 1, 1, 'bloodhound fur', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 1, 0, 0, 0),
(204, 'Locate Creature', 1, 4, 0, '1 action', 0, 0, 0, 1, 1, 1, 'bloodhound fur', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 1, 0, 0, 1),
(205, 'Locate Object', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'forked twig', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 1, 1, 0, 0, 1),
(206, 'Longstrider', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'pinch of dirt', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 1, 0, 0, 1),
(207, 'Mage Armor', 1, 1, 0, '1 action', 0, 0, 0, 1, 1, 1, 'piece of cured leather', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(208, 'Mage Hand', 1, 0, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(209, 'Magic Circle', 1, 3, 0, '1 minute', 10, 0, 0, 1, 1, 1, 'HOLY WATER or Fe/Ag DUST', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 1, 1),
(210, 'Magic Jar', 1, 6, 0, '1 minute', 0, 0, 0, 1, 1, 1, 'ornamental container', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(211, 'Magic Missile', 1, 1, 0, '1 action', 120, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Force', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(212, 'Magic Mouth', 1, 2, 1, '1 minute', 30, 0, 0, 1, 1, 1, 'honeycomb and JADE DUST', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(213, 'Magic Weapon', 1, 2, 0, '1 bonus action', 0, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 1, 0, 0, 0, 1),
(214, 'Major Image', 1, 3, 0, '1 action', 120, 0, 0, 1, 1, 1, 'bit of fleece', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(215, 'Mass Cure Wounds', 1, 5, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 0, 0, 0),
(216, 'Mass Heal', 1, 9, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(217, 'Mass Healing Word', 1, 3, 0, '1 bonus action', 60, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 0, 0, 0, 0, 0, 0),
(218, 'Mass Suggestion', 1, 6, 0, '1 action', 60, 0, 0, 1, 0, 1, 'snake\'s tongue, honeycomb', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(219, 'Maze', 1, 8, 0, '1 action', 60, 0, 0, 1, 1, 0, '', 1, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(220, 'Meld into Stone', 1, 3, 1, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 0, 0, 0),
(221, 'Melf\'s Acid Arrow', 1, 2, 0, '1 action', 90, 0, 0, 1, 1, 1, 'rhubarb leaf, adder\'s stomach', 0, 0, '', '', '', 'Acid', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 0, 0, 1),
(222, 'Mending', 1, 0, 0, '1 minute', 0, 0, 0, 1, 1, 1, 'two lodestones', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 1, 0, 0, 1, 0, 1),
(223, 'Message', 1, 0, 0, '1 action', 120, 0, 0, 1, 1, 1, 'piece of copper wire', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 0, 1),
(224, 'Meteor Swarm', 1, 9, 0, '1 action', 1, 0, 0, 1, 1, 0, '', 0, 0, '', '', '', 'Fire+Bludgeoning', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 1, 0, 1),
(225, 'Mind Blank', 1, 8, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(226, 'Minor Illusion', 1, 0, 0, '1 action', 30, 0, 0, 0, 1, 1, 'bit of fleece', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 1, 1, 1),
(227, 'Mirage Arcane', 1, 7, 0, '10 minutes', 0, 0, 0, 1, 1, 0, '', 0, 10, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 1, 0, 0, 0, 0, 1),
(228, 'Mirror Image', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 0, '', 0, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 1, 1, 0, 0, 1, 1, 1),
(229, 'Mislead', 1, 5, 0, '1 action', 0, 0, 0, 0, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(230, 'Misty Step', 1, 2, 0, '1 bonus action', 0, 0, 0, 1, 0, 0, '', 0, 0, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 1, 0, 1, 1, 1),
(231, 'Modify Memory', 1, 5, 0, '1 action', 30, 0, 0, 1, 1, 0, '', 1, 1, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 0, 0, 0, 1),
(232, 'Moonbeam', 1, 2, 0, '1 action', 120, 0, 0, 1, 1, 1, 'moonseed seeds, feldspar', 1, 1, '', '', '', 'Radiant', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 1, 0, 0, 0, 0),
(233, 'Mordenkainen\'s Faithful Hound', 1, 4, 0, '1 action', 30, 0, 0, 1, 1, 1, 'silver whistle, bone, thread', 0, 8, '', '', '', 'Piercing', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(234, 'Mordenkainen\'s Magnificent Mansion', 1, 7, 0, '1 minute', 300, 0, 0, 1, 1, 1, 'portal(5),marble(5),spoon(5)', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(235, 'Mordenkainen\'s Private Sanctum', 1, 4, 0, '10 minutes', 120, 0, 0, 1, 1, 1, 'lead,glass,cloth,chrysolite', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(236, 'Mordenkainen\'s Sword', 1, 7, 0, '1 action', 60, 0, 0, 1, 1, 1, 'mini platinum sword', 1, 1, '', '', '', 'Force', 0, 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 0, 1),
(237, 'Move Earth', 1, 6, 0, '1 action', 120, 0, 0, 1, 1, 1, 'iron blade, bag of soil', 1, 2, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 1, 0, 0, 1, 0, 1),
(238, 'Nondetection', 1, 3, 0, '1 action', 0, 0, 0, 1, 1, 1, 'DIAMOND DUST', 0, 8, '', '', '', '', 0, 0, 0, 0, 0, '', '', 1, 1, 0, 0, 1, 0, 0, 1),
(239, 'Nystul\'s Magic Aura', 1, 2, 0, '1 action', 0, 0, 0, 1, 1, 1, 'small square of silk', 0, 24, '', '', '', '', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1),
(240, 'Otiluke\'s Freezing Sphere', 1, 6, 0, '1 action', 300, 0, 0, 1, 1, 1, 'small crystal sphere', 0, 0, '', '', '', 'Cold', 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Campaign`
--

CREATE TABLE `Campaign` (
  `campaignID` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `userID` int(11) NOT NULL,
  `partySize` int(11) NOT NULL,
  `partyKey` varchar(5) NOT NULL,
  `notes` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Campaign`
--

INSERT INTO `Campaign` (`campaignID`, `name`, `userID`, `partySize`, `partyKey`, `notes`) VALUES
(4, 'test_campaign', 117, 6, '12345', 'testing'),
(123, 'yay', 131, 9, '9', 'create notes for the dm\n\n'),
(333, 'Testing', 131, 3, '222', ''),
(444, 'testing more', 131, 3, '456', NULL),
(555, 'Testing Campaign', 131, 3, '3', NULL),
(777, 'new test camp', 131, 3, '999', ''),
(778, 'testValue', 131, 1, 'n4plr', NULL),
(779, '', 131, 1, '3fa9y', NULL),
(780, '', 131, 1, 'qr33b', NULL),
(781, '', 131, 1, '85ujr', NULL),
(782, '', 131, 1, '4b1b1', NULL),
(783, '', 131, 1, 'ru9pm', NULL),
(785, 'yaaaaayy', 131, 6, 'rok9q', NULL),
(786, 'woop woop', 131, 2, 'ijvab', NULL),
(787, 'hellooooo', 131, 2, 'nt1xb', NULL),
(788, 'DandD', 131, 1, 'jqvk1', NULL),
(789, 'meow', 131, 2, '1jzxm', NULL),
(790, 'Lebron', 114, 26, 'kutqm', NULL),
(791, 'Lebron', 114, 2, 'g7m2j', NULL),
(792, 'meowmeow', 131, 1, '36gn7', NULL),
(793, 'meowmeowmeow', 131, 2, 'acylw', NULL),
(794, 'whyyy', 131, 1, 'n7qt3', NULL),
(795, 'whyyy', 131, 1, 'gzvr7', NULL),
(796, 'issssss', 131, 3, 'fr4iq', NULL),
(797, 'thisss', 131, 2, 'bon7u', NULL),
(798, 'happeeninnnggg', 131, 1, '39fti', NULL),
(799, '???????', 131, 1, '4lmy3', NULL),
(800, 'hello', 131, 1, 'aza6c', NULL),
(801, '(^q^)', 131, 1, 'xcs99', NULL),
(802, 'waffles', 131, 1, 'vzs1x', NULL),
(803, 'pancakes', 131, 1, '4bjfa', NULL),
(804, 'halflings', 131, 1, 'upri3', NULL),
(805, 'arecool', 131, 1, '1vwtt', NULL),
(806, 'seaturtle', 131, 1, 'jszvu', NULL),
(807, 'orcas', 131, 1, 'ua1ur', NULL),
(808, 'orcas', 131, 1, 'glp2q', NULL),
(809, 'jellyfish', 131, 1, 'uxsbg', NULL),
(810, 'jellyfish', 131, 1, 'u7mdv', NULL),
(811, 'jellyfish', 131, 1, 'f62qe', NULL),
(812, '', 131, 1, 'nfcgg', NULL),
(813, '', 131, 1, 'p98q9', NULL),
(814, 'seaangel', 131, 1, 'be5ey', NULL),
(815, 'seaangel', 131, 1, 'v3k4e', NULL),
(816, 'Krabs', 131, 1, '1rx85', NULL),
(817, 'I think I got this', 131, 1, 'vaos8', NULL),
(818, 'I think I got this', 131, 1, '3ulb4', NULL),
(819, 'maybenot', 131, 1, 'pu1oe', NULL),
(820, 'maybenot', 131, 1, 'z9ukv', NULL),
(821, 'mmmmm', 131, 1, 'gfqqg', NULL),
(822, 'eureka', 131, 1, 'r8d8p', NULL),
(823, 'awesomeeee', 131, 1, '1qyqb', NULL),
(824, 'fern is a beast', 118, 1, '2uozd', NULL),
(825, 'TestMe', 131, 1, '9dsm2', NULL),
(826, 'Awesomeeee', 131, 1, '38jsr', NULL),
(827, 'hdasdkasd', 131, 1, 'pvtk2', NULL),
(828, 'helloooo', 131, 1, '32ypz', NULL),
(829, 'sadasdsa', 131, 1, '428kw', NULL),
(830, 'safa', 131, 1, 'obj5x', NULL),
(831, 'dasajhh', 131, 1, '3wj5r', NULL),
(832, 'hjhjh', 131, 1, 'lnllb', NULL),
(833, 'djaksdjs', 131, 1, 'cxj3l', NULL),
(834, 'mkmk', 131, 1, 'qrhym', NULL),
(835, 'dsadsada', 131, 1, 'mt7l3', NULL),
(836, 'yaaay', 131, 1, '1cjqr', NULL),
(837, 'johns camp', 134, 1, 's58qg', NULL),
(838, 'nameifthis', 131, 1, 'hyyk8', NULL),
(839, 'woooooooo', 131, 1, 'fr9b3', NULL),
(840, 'mewkaas', 131, 1, 'po3d5', NULL),
(841, 'jsdbnvkfsda', 131, 3, 'mbtoy', 'DM Notes!!\n\n'),
(842, 'Losers United', 138, 1, '2h6jy', ''),
(843, 'Campaign', 138, 1, 'mx1zb', NULL),
(844, 'Test', 121, 2, '6tr4u', NULL),
(845, 'hahahahhhhhh', 134, 1, 'jcqt1', 'mee'),
(846, 'Wowie', 138, 2, 'dpsp5', NULL),
(847, 'this is a campaign', 139, 1, 's8rej', NULL),
(848, 'thisCampaign', 141, 1, '242as', NULL),
(849, 'The Adventure', 145, 3, 'cfu7e', 'party key: cfu7e\n\n'),
(850, 'Adventure2', 145, 1, 'm3vuo', NULL),
(851, 'New Adventure', 146, 1, 'jwluw', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `CharacterAbilities`
--

CREATE TABLE `CharacterAbilities` (
  `characterID` int(11) NOT NULL,
  `abilityID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `CharacterItems`
--

CREATE TABLE `CharacterItems` (
  `characterID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `proficiency` tinyint(1) NOT NULL,
  `usesRemaining` int(11) DEFAULT '1',
  `attackBonus` int(11) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Characters`
--

CREATE TABLE `Characters` (
  `characterID` int(11) NOT NULL,
  `raceID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `classID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `personality` text NOT NULL,
  `ideals` text NOT NULL,
  `bonds` text NOT NULL,
  `flaws` text NOT NULL,
  `languages` text NOT NULL,
  `passiveWisdom` int(11) NOT NULL,
  `proficiencyBonus` int(11) NOT NULL,
  `featuresAndTraits` text NOT NULL,
  `speed` int(11) DEFAULT NULL,
  `gold` int(11) NOT NULL,
  `silver` int(11) NOT NULL,
  `copper` int(11) NOT NULL,
  `spellCastingAbility` varchar(3) DEFAULT NULL,
  `background` text NOT NULL,
  `level` int(11) NOT NULL,
  `expPoints` int(11) NOT NULL,
  `armorClass` int(11) NOT NULL,
  `maxHP` int(11) NOT NULL,
  `currentHP` int(11) NOT NULL,
  `inspiration` int(11) NOT NULL,
  `alignment` varchar(15) NOT NULL,
  `strength` int(11) NOT NULL,
  `dexterity` int(11) NOT NULL,
  `intelligence` int(11) NOT NULL,
  `wisdom` int(11) NOT NULL,
  `constitution` int(11) NOT NULL,
  `charisma` int(11) NOT NULL,
  `notes` text,
  `initiative` int(11) NOT NULL DEFAULT '0',
  `skillProf` text,
  `itemProf` text,
  `abilities` text,
  `inventory` text,
  `weapons` text,
  `tempHP` int(11) NOT NULL DEFAULT '0',
  `spells` text NOT NULL,
  `savingThrows` text NOT NULL,
  `hitDie` int(11) NOT NULL DEFAULT '6'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Characters`
--

INSERT INTO `Characters` (`characterID`, `raceID`, `userID`, `classID`, `name`, `personality`, `ideals`, `bonds`, `flaws`, `languages`, `passiveWisdom`, `proficiencyBonus`, `featuresAndTraits`, `speed`, `gold`, `silver`, `copper`, `spellCastingAbility`, `background`, `level`, `expPoints`, `armorClass`, `maxHP`, `currentHP`, `inspiration`, `alignment`, `strength`, `dexterity`, `intelligence`, `wisdom`, `constitution`, `charisma`, `notes`, `initiative`, `skillProf`, `itemProf`, `abilities`, `inventory`, `weapons`, `tempHP`, `spells`, `savingThrows`, `hitDie`) VALUES
(2, 12, 121, 12, 'Twelve', 'Fierce, fun, flirty', 'Not to make friends but to win', 'Mariah, Beyonce', 'Flawless', 'twelve, trash talk', 12, 2, 'twelve (altered yet again)', 12, 12, 12, 12, 'Cha', 'twelve', 12, 12, 12, 12, 9, 12, 'Chaotic Neutral', 12, 12, 12, 12, 12, 12, 'ten? yes!\n\n', 12, 'Arcana', 'twelve', 'twelve', 'Diamonds', 'twelve', 12, 'twelves first spell', 'twelve', 12),
(5, 1, 114, 1, 'zero', '', '', '', '', 'zero', 0, 2, '', 0, 0, 0, 0, 'zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(6, 1, 114, 1, 'Languages Works', '', '', '', '', 'Common', 0, 2, '', 0, 0, 0, 0, 'zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(8, 1, 114, 1, 'passiveWisdom Works', '', '', '', '', 'Common', 10, 2, '', 0, 0, 0, 0, 'zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(12, 4, 114, 4, 'Paul', '', '', '', '', 'none', 0, 2, '', 0, 0, 0, 0, 'Zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(13, 2, 114, 2, 'Johnny', '', '', '', '', 'none', 0, 2, '', 0, 0, 0, 0, 'Zer', '', 1, 0, 0, 0, 0, 36, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(14, 2, 114, 2, '', '', '', '', '', 'none', 0, 2, '', 0, 0, 0, 0, 'Zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(15, 2, 114, 2, 'Stevie', '', '', '', '', 'none', 0, 2, '', 0, 0, 0, 0, 'Zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(16, 2, 114, 2, '', '', '', '', '', 'none', 0, 2, '', 0, 0, 0, 0, 'Zer', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(18, 5, 114, 5, ':(', '', '', '', '', '', 0, 0, '', 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(19, 2, 114, 2, 'Nameless', '', '', '', '', '', 0, 0, '', 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(20, 2, 114, 2, 'Nameless', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 0, 0, '', 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(21, 12, 114, 2, 'Nameless', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Ore', 0, 0, '', 0, 0, 0, 0, 'Cha', '', 1, 0, 0, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(22, 10, 114, 10, 'Nameless', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 0, 2, 'Features and Traits', 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(23, 10, 114, 10, 'Jim', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes testing savewwwow\n\nhere is the stuf\n\n\n\nhi still there?', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(24, 10, 114, 10, 'Johnny', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 0, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 36, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(25, 10, 114, 10, 'Speed', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, '', '', 1, 0, 0, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(26, 10, 114, 10, 'SpellCastingAbility', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', '', 1, 0, 0, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(27, 10, 114, 10, 'Armor Class', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', '', 1, 0, 29, 0, 0, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(28, 10, 114, 10, 'Hit Points', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', '', 1, 0, 14, 6, 6, 0, 'True Neutral', 0, 0, 0, 0, 0, 0, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(29, 10, 114, 10, 'Stats', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', '', 1, 0, 14, 6, 6, 0, 'True Neutral', 12, 19, 13, 11, 10, 17, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(30, 10, 114, 10, 'Inventory', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', '', 1, 0, 14, 6, 6, 0, 'True Neutral', 12, 19, 13, 11, 10, 17, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(31, 5, 131, 2, 'Pluck Sweetsong', 'Person here', 'Ideals', 'Bonds', 'Flaws', 'Languages', 11, 2, 'Features and Traits', 35, 0, 0, 0, 'Cha', 'Background', 1, 0, 14, 8, 8, 0, 'True Neutral', 10, 19, 12, 19, 10, 10, 'Notes !\n\n1) fight\n2)dont die\n', 0, 'null', NULL, NULL, NULL, NULL, 0, '', '', 6),
(32, 5, 114, 2, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 11, 2, 'Features and Traits', 35, 0, 0, 0, 'Cha', 'Background', 1, 0, 14, 8, 8, 0, 'True Neutral', 12, 19, 13, 12, 10, 16, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(33, 7, 131, 5, 'Dungeon Master', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, '', 'Background', 1, 0, 9, 9, 9, 0, 'True Neutral', 16, 8, 14, 11, 9, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(34, 2, 114, 4, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 14, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 9, 11, 11, 0, 'True Neutral', 16, 9, 6, 19, 15, 15, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(35, 11, 114, 12, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 14, 2, 'Features and Traits', 25, 0, 0, 0, 'Int', 'Background', 1, 0, 10, 10, 10, 0, 'True Neutral', 14, 11, 7, 18, 19, 9, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(36, 4, 114, 6, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 11, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 14, 10, 10, 0, 'True Neutral', 17, 18, 13, 13, 15, 8, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(37, 14, 114, 11, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 30, 0, 0, 0, 'Cha', 'Background', 1, 0, 10, 8, 8, 0, 'Alignment', 11, 11, 11, 11, 10, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(38, 14, 114, 11, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 30, 0, 0, 0, 'Cha', 'Background', 1, 0, 10, 8, 8, 0, 'Alignment', 11, 11, 11, 11, 10, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(39, 14, 114, 11, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 5, 2, 'Features and Traits', 30, 0, 0, 0, 'Cha', 'Background', 1, 0, 5, 3, 3, 0, 'Alignment', 1, 1, 2, 1, 1, 3, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(40, 14, 114, 11, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 5, 2, 'Features and Traits', 30, 0, 0, 0, 'Cha', 'Background', 1, 0, 5, 3, 3, 0, 'Alignment', 1, 1, 2, 1, 1, 3, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(41, 14, 114, 11, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 5, 2, 'Features and Traits', 30, 0, 0, 0, 'Cha', 'Background', 1, 0, 5, 3, 3, 0, 'Alignment', 1, 1, 2, 1, 1, 3, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(42, 4, 114, 12, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 5, 2, 'Features and Traits', 30, 0, 0, 0, 'Int', 'Background', 1, 0, 6, 1, 1, 0, 'Alignment', 1, 3, 2, 1, 1, 1, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(43, 4, 114, 12, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 5, 2, 'Features and Traits', 30, 0, 0, 0, 'Int', 'Background', 1, 0, 6, 1, 1, 0, 'Alignment', 1, 3, 2, 1, 1, 1, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(44, 12, 114, 5, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 12, 10, 10, 10, 11, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(45, 12, 114, 5, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 12, 10, 10, 10, 11, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(46, 12, 114, 5, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 12, 10, 10, 10, 11, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(47, 8, 114, 3, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 11, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 11, 10, 10, 0, 'Alignment', 16, 13, 17, 12, 15, 17, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(49, 3, 114, 8, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(50, 3, 114, 8, '', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(51, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(52, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(53, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(54, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(55, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(56, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(57, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(58, 3, 114, 8, 'Pluck Sweetsong', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(59, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(60, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(61, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(62, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(63, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(64, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(65, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(66, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(67, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(68, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(69, 3, 114, 8, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 12, 10, 10, 10, 12, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(70, 1, 114, 1, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 30, 0, 0, 0, 'cha', 'Background', 1, 0, 12, 15, 15, 0, 'Alignment', 10, 10, 10, 10, 10, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(71, 1, 114, 1, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 10, 0, 0, 0, 'cha', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 10, 10, 10, 10, 10, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(72, 1, 114, 1, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 10, 0, 0, 0, 'cha', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 10, 10, 10, 10, 10, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(73, 1, 114, 1, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 10, 0, 0, 0, 'cha', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 10, 10, 10, 10, 10, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(74, 1, 114, 1, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 10, 2, 'Features and Traits', 10, 0, 0, 0, 'cha', 'Background', 1, 0, 10, 10, 10, 0, 'Alignment', 10, 10, 10, 10, 10, 10, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(75, 4, 114, 5, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 14, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 12, 10, 10, 0, 'Alignment', 7, 14, 17, 18, 10, 14, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(76, 4, 114, 5, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 14, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 12, 10, 10, 0, 'Alignment', 7, 14, 17, 18, 10, 14, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(77, 4, 114, 5, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 14, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 12, 10, 10, 0, 'Alignment', 7, 14, 17, 18, 10, 14, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(78, 7, 114, 6, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 13, 2, 'Features and Traits', 25, 0, 0, 0, '', 'Background', 1, 0, 11, 8, 8, 0, 'Alignment', 11, 13, 12, 17, 10, 16, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(79, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(80, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(81, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(82, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(83, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(84, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(85, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(86, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(87, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(88, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 6, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(89, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(90, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(91, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(92, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(93, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Languages', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, NULL, NULL, NULL, NULL, NULL, 0, '', '', 6),
(94, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Dwarvish, Druidic', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, 'Nature, Survival', 'Battleaxe, Handaxe, Throwing Hammer, Warhammer, Smith Tools, Brewer supplies, Mason tools, Light Armor, Medium Armor, Light Armor, Medium Armor, Shield, Club, Dagger, Dart, Javelin, Mace, Quarterstaff, Scimitar, Sickle, Sling, Spear, Herbalism Kit', 'abilities', 'inventory', NULL, 0, '', '', 6),
(95, 3, 114, 4, 'Firstname Lastname', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Dwarvish, Druidic', 8, 2, 'Features and Traits', 25, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 10, 10, 0, 'Alignment', 8, 6, 12, 6, 14, 12, 'Notes', 0, 'Nature, Survival', 'Battleaxe, Handaxe, Throwing Hammer, Warhammer, Smith Tools, Brewer supplies, Mason tools, Light Armor, Medium Armor, Light Armor, Medium Armor, Shield, Club, Dagger, Dart, Javelin, Mace, Quarterstaff, Scimitar, Sickle, Sling, Spear, Herbalism Kit', 'Darkvision, Dwarven Resilience, Stonecunning, Dwarven Armor Training, Spellcasting', 'Wooden Shield, Scimitar, Leather Armor, Explorer Pack', NULL, 0, '', '', 6),
(103, 6, 118, 1, 'fern', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 5, 7, 7, 0, 'Alignment', 1, 1, 2, 7, 1, 7, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(104, 6, 118, 1, 'fernando', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 7, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 13, 8, 8, 0, 'Alignment', 17, 17, 17, 5, 2, 14, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(105, 6, 131, 1, 'fdnakjsdn', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 14, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 14, 13, 13, 0, 'Alignment', 16, 19, 11, 19, 13, 18, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(106, 6, 131, 1, 'awesome', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 11, 14, 14, 0, 'Alignment', 8, 12, 9, 6, 14, 16, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(107, 6, 131, 1, 'awesome', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 11, 14, 14, 0, 'Alignment', 8, 12, 9, 6, 14, 16, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(108, 6, 131, 1, 'jkdshf', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 9, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 15, 10, 10, 0, 'Alignment', 17, 20, 11, 9, 7, 14, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(109, 6, 131, 1, 'meeeee', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 7, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 12, 11, 11, 0, 'Alignment', 19, 14, 15, 5, 9, 16, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(110, 6, 131, 1, 'please', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 6, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 13, 17, 17, 0, 'Alignment', 13, 16, 12, 2, 20, 9, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(111, 6, 131, 1, 'mlsamfska', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 7, 15, 15, 0, 'Alignment', 14, 4, 8, 7, 16, 10, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(112, 6, 131, 1, 'mlsamfska', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 7, 15, 15, 0, 'Alignment', 14, 4, 8, 7, 16, 10, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(113, 6, 131, 1, 'testingfnaskjfn', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 13, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 15, 12, 12, 0, 'Alignment', 1, 20, 7, 17, 11, 18, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(114, 6, 131, 1, 'dmskladmlsadma', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 9, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 11, 8, 8, 0, 'Alignment', 16, 12, 6, 8, 3, 3, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(115, 6, 131, 1, 'jwfcljacdjnacdjh', 'Sassy', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 8, 13, 13, 0, 'Alignment', 1, 6, 13, 7, 13, 19, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(116, 6, 131, 1, 'dhbsakcjbszbc', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 7, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 7, 14, 14, 0, 'Alignment', 14, 4, 15, 4, 14, 14, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(117, 6, 121, 1, 'hcjwkdcbsa', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 6, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 12, 9, 9, 0, 'Alignment', 20, 15, 7, 2, 4, 2, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(118, 6, 121, 1, 'hcjwkdcbsa', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 6, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 12, 9, 9, 0, 'Alignment', 20, 15, 7, 2, 4, 2, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(119, 6, 121, 1, 'dwjandkjWSNKJDQ', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 15, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 11, 14, 14, 0, 'Alignment', 17, 13, 19, 20, 14, 10, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(120, 6, 121, 1, 'jdbsaj', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 15, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 9, 7, 7, 0, 'Alignment', 10, 8, 16, 20, 1, 4, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(121, 6, 121, 1, 'd msa,ds', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 12, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 9, 13, 13, 0, 'Alignment', 16, 9, 18, 15, 12, 19, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(122, 6, 121, 1, 'dsada', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 15, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 6, 13, 13, 0, 'Alignment', 3, 3, 1, 20, 12, 12, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(123, 6, 121, 1, 'dsadsa', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 5, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 8, 11, 11, 0, 'Alignment', 1, 7, 9, 1, 9, 6, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(124, 6, 121, 1, 'jdasdsa', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 8, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 14, 13, 13, 0, 'Alignment', 1, 18, 4, 6, 12, 6, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(125, 1, 121, 1, 'Lebron', 'dank', 'none', 'yeah', 'yooo', 'French', 12, 12, 'a lot', 12, 12, 8, 8, 'Cha', 'twelve', 12, 12, 12, 12, 9, 12, 'Chaotic', 9, 8, 7, 9, 9, 8, NULL, 9, 'Arcana', 'twelve', 'twelve', 'Diamonds', 'twelve', 12, 'twelves first spell', 'twelve', 12),
(126, 7, 138, 2, 'Susie', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Gnomish', 14, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', 'Background', 1, 0, 15, 7, 7, 0, 'Alignment', 13, 20, 17, 18, 9, 8, 'Notes', 0, 'Sleight Of Hand, Acrobatics, Performance', ', Light Armor, Simple Weapon, Hand Crossbow, Longsword, Rapier, Shortsword, Lute, Flute, Viol', 'Darkvision, Gnome Cunning, Natural Illusionist, Speak with Small Beasts, Bardic Inspiration, Spellcasting', 'Entertainer Pack, Lute, Leather Armor', 'Rapier, Dagger', 0, '', 'Dexterity, Charisma', 6),
(127, 6, 131, 1, 'dsnakdlnas', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 9, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 6, 8, 8, 0, 'Alignment', 5, 3, 17, 8, 3, 18, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(128, 6, 134, 1, 'itsmemario', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 13, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 10, 9, 9, 0, 'Alignment', 11, 10, 13, 17, 4, 16, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(129, 7, 131, 2, 'gshsnz', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Gnomish', 5, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', 'Background', 1, 0, 7, 7, 7, 0, 'Alignment', 3, 5, 16, 1, 8, 15, 'Notes', 0, 'Sleight Of Hand, Acrobatics, Performance', ', Light Armor, Simple Weapon, Hand Crossbow, Longsword, Rapier, Shortsword, Lute, Flute, Viol', 'Darkvision, Gnome Cunning, Natural Illusionist, Speak with Small Beasts, Bardic Inspiration, Spellcasting', 'Entertainer Pack, Lute, Leather Armor', 'Rapier, Dagger', 0, '', 'Dexterity, Charisma', 6),
(130, 7, 139, 2, 'danny', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Gnomish', 10, 2, 'Features and Traits', 25, 0, 0, 0, 'Cha', 'Background', 1, 0, 13, 3, 3, 0, 'Alignment', 16, 16, 12, 10, 1, 8, 'Notes', 0, 'Sleight Of Hand, Acrobatics, Performance', ', Light Armor, Simple Weapon, Hand Crossbow, Longsword, Rapier, Shortsword, Lute, Flute, Viol', 'Darkvision, Gnome Cunning, Natural Illusionist, Speak with Small Beasts, Bardic Inspiration, Spellcasting', 'Entertainer Pack, Lute, Leather Armor', 'Rapier, Dagger', 0, '', 'Dexterity, Charisma', 6),
(131, 1, 121, 1, 'Lebron', 'dank', 'none', 'yeah', 'yooo', 'French', 12, 12, 'a lot', 12, 12, 8, 8, NULL, 'twelve', 12, 12, 12, 12, 9, 12, 'Chaotic', 9, 8, 7, 9, 9, 8, NULL, 9, 'Arcana', 'twelve', 'twelve', 'Diamonds', 'twelve', 12, 'twelves first spell', 'twelve', 12),
(132, 6, 134, 1, 'meeeee', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 5, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 15, 16, 16, 0, 'Alignment', 15, 20, 1, 1, 19, 4, 'NotesSs', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(133, 6, 141, 1, 'namehere', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 7, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 9, 8, 8, 0, 'Alignment', 20, 8, 8, 5, 2, 12, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(134, 6, 131, 1, 'Arisa the Brave', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 9, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 10, 11, 11, 0, 'Alignment', 10, 10, 7, 10, 9, 9, 'rolled 15\n\n\n', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6),
(135, 13, 134, 5, 'John the guy', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 14, 2, 'Features and Traits', 30, 0, 0, 0, '', 'Background', 1, 0, 14, 7, 7, 0, 'Alignment', 7, 19, 4, 18, 4, 15, 'Notes', 0, 'Athletics, Acrobatics', ', Armor, Shield, Simple Weapons, Martial Weapons', 'Extra Language, Second Wind', 'Chainmail, Explorer Pack', 'Battleaxe, Rapier, 2 Handaxes', 0, '', 'Strength, Constitution', 6),
(136, 1, 145, 3, 'Jon the other guy', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, Draconic', 10, 2, 'Features and Traits', 30, 0, 0, 0, 'Wis', 'Background', 1, 0, 8, 13, 13, 0, 'Alignment', 17, 3, 11, 10, 20, 21, 'Notes', 0, 'Medicine, Religion', ', Light Armor, Medium Armor, Shield, Simple Weapon', 'Draconic Ancestry, Spellcasting', 'Leather Armor, Priest Pack, Shield', 'Mace, Quarterstaff', 0, '', 'Wisdom, Charisma', 6),
(137, 6, 146, 1, 'name here', 'Personality', 'Ideals', 'Bonds', 'Flaws', 'Common, ', 5, 2, 'Features and Traits', 0, 0, 0, 0, '', 'Background', 1, 0, 8, 12, 12, 0, 'Alignment', 4, 6, 17, 1, 10, 20, 'Notes', 0, 'Athletics, Survival', ', Simple Weapon, Martial Weapon, Light Armor, Medium Armor, Shield', ', Rage', 'Explorer Pack', '4 Javelins', 0, '', 'Strength, Constitution', 6);

-- --------------------------------------------------------

--
-- Table structure for table `CharactersCampaign`
--

CREATE TABLE `CharactersCampaign` (
  `campaignID` int(11) NOT NULL,
  `characterID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CharactersCampaign`
--

INSERT INTO `CharactersCampaign` (`campaignID`, `characterID`) VALUES
(4, 2),
(4, 31),
(123, 31),
(333, 31),
(444, 31),
(555, 31),
(777, 33),
(790, 115),
(791, 116),
(790, 117),
(790, 118),
(787, 119),
(786, 120),
(789, 121),
(797, 122),
(796, 123),
(793, 124),
(846, 127),
(785, 130),
(4, 132),
(4, 133),
(849, 134),
(841, 135),
(841, 136),
(849, 137);

-- --------------------------------------------------------

--
-- Table structure for table `Classes`
--

CREATE TABLE `Classes` (
  `classID` int(11) NOT NULL,
  `hitDie` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `strSVProficiency` tinyint(1) NOT NULL DEFAULT '0',
  `dexSVProficiency` tinyint(1) NOT NULL DEFAULT '0',
  `conSVProficiency` tinyint(1) NOT NULL DEFAULT '0',
  `intSVProficiency` tinyint(1) NOT NULL DEFAULT '0',
  `wisSVProficiency` tinyint(1) NOT NULL DEFAULT '0',
  `charSVProficiency` tinyint(1) NOT NULL DEFAULT '0',
  `spellCastAbility` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Classes`
--

INSERT INTO `Classes` (`classID`, `hitDie`, `name`, `strSVProficiency`, `dexSVProficiency`, `conSVProficiency`, `intSVProficiency`, `wisSVProficiency`, `charSVProficiency`, `spellCastAbility`) VALUES
(1, 12, 'Barbarian', 1, 0, 1, 0, 0, 0, NULL),
(2, 8, 'Bard', 0, 1, 0, 0, 0, 1, 'cha'),
(3, 8, 'Cleric', 0, 0, 0, 0, 1, 1, 'wis'),
(4, 8, 'Druid', 0, 0, 0, 1, 1, 0, 'wis'),
(5, 10, 'Fighter', 1, 0, 1, 0, 0, 0, NULL),
(6, 8, 'Monk', 1, 1, 0, 0, 0, 0, NULL),
(7, 10, 'Paladin', 0, 0, 0, 0, 1, 1, 'cha'),
(8, 10, 'Ranger', 1, 1, 0, 0, 0, 0, 'wis'),
(9, 8, 'Rogue', 0, 1, 0, 1, 0, 0, NULL),
(10, 6, 'Sorcerer', 0, 0, 1, 0, 0, 1, 'cha'),
(11, 8, 'Warlock', 0, 0, 0, 0, 1, 1, 'cha'),
(12, 6, 'Wizard', 0, 0, 0, 1, 1, 0, 'int');

-- --------------------------------------------------------

--
-- Table structure for table `Enemies`
--

CREATE TABLE `Enemies` (
  `enemiesID` int(11) NOT NULL,
  `campaignID` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `maxHP` int(11) NOT NULL,
  `currentHP` int(11) NOT NULL,
  `dexMod` int(11) NOT NULL DEFAULT '0',
  `strMod` int(11) NOT NULL DEFAULT '0',
  `conMod` int(11) NOT NULL DEFAULT '0',
  `intMod` int(11) NOT NULL DEFAULT '0',
  `wisMod` int(11) NOT NULL DEFAULT '0',
  `charMod` int(11) NOT NULL DEFAULT '0',
  `numOfAttacks` int(11) NOT NULL DEFAULT '1',
  `ac` int(11) NOT NULL DEFAULT '0',
  `initiative` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Enemies`
--

INSERT INTO `Enemies` (`enemiesID`, `campaignID`, `name`, `maxHP`, `currentHP`, `dexMod`, `strMod`, `conMod`, `intMod`, `wisMod`, `charMod`, `numOfAttacks`, `ac`, `initiative`) VALUES
(1, 4, 'Dire Wolf', 37, 37, 2, 3, 2, -4, 1, -2, 0, 14, 0),
(2, 4, 'Dire Wolf', 37, 37, 2, 3, 2, -4, 1, -2, 0, 14, 0),
(3, 4, 'Dire Wolf', 37, 37, 2, 3, 2, -4, 1, -2, 0, 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Friends`
--

CREATE TABLE `Friends` (
  `userID` int(11) NOT NULL,
  `friendID` int(11) NOT NULL,
  `isConfirmed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Friends`
--

INSERT INTO `Friends` (`userID`, `friendID`, `isConfirmed`) VALUES
(118, 121, 0),
(121, 117, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Items`
--

CREATE TABLE `Items` (
  `itemID` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` text,
  `weight` float DEFAULT NULL,
  `usesAvailable` int(11) DEFAULT NULL,
  `worthGold` int(11) DEFAULT NULL,
  `worthSilver` int(11) DEFAULT NULL,
  `worthCopper` int(11) DEFAULT NULL,
  `enhanceAbilityHP` tinyint(1) NOT NULL DEFAULT '0',
  `damageType` varchar(20) DEFAULT NULL,
  `damage` varchar(6) DEFAULT NULL,
  `weaponType` varchar(20) DEFAULT NULL,
  `weaponClass` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Items`
--

INSERT INTO `Items` (`itemID`, `name`, `description`, `weight`, `usesAvailable`, `worthGold`, `worthSilver`, `worthCopper`, `enhanceAbilityHP`, `damageType`, `damage`, `weaponType`, `weaponClass`) VALUES
(1, 'Club', NULL, 2, NULL, NULL, 1, NULL, 0, 'bludgeoning', '1d4', 'melee', 'simple'),
(2, 'Dagger', NULL, 1, NULL, NULL, 2, NULL, 0, 'piercing', '1d4', 'melee', 'simple'),
(3, 'Greatclub', NULL, 10, NULL, NULL, 2, NULL, 0, 'bludgeoning', '1d8', 'melee', 'simple'),
(4, 'Handaxe', NULL, 2, NULL, NULL, 5, NULL, 0, 'slashing', '1d6', 'melee', 'simple'),
(5, 'Javelin', NULL, 2, NULL, 2, NULL, NULL, 0, 'piercing', '1d6', 'melee', 'simple'),
(6, 'Light Hammer', NULL, 2, NULL, 5, NULL, NULL, 0, 'bludgeoning', '1d4', 'melee', 'simple'),
(7, 'Mace', NULL, 4, NULL, NULL, 2, NULL, 0, 'bludgeoning', '1d6', 'melee', 'simple'),
(8, 'Quarterstaff', NULL, 4, NULL, 1, NULL, NULL, 0, 'bludgeoning', '1d6', 'melee', 'simple'),
(9, 'Sickle', NULL, 2, NULL, 1, NULL, NULL, 0, 'slashing', '1d4', 'melee', 'simple'),
(10, 'Spear', NULL, 3, NULL, NULL, NULL, NULL, 0, 'piercing', '1d6', 'melee', 'simple'),
(11, 'Crossbow, light', 'range(80/320)', 5, NULL, 25, NULL, NULL, 0, 'piercing', '1d8', 'ranged', 'simple'),
(12, 'Dart', 'range(20/60)', 0.25, NULL, NULL, NULL, 5, 0, 'piercing', '1d4', 'ranged', 'simple'),
(13, 'Shortbow', 'range(80/320)', 2, NULL, 25, NULL, NULL, 0, 'piercing', '1d6', 'ranged', 'simple'),
(14, 'Sling', 'range(20/120)', 0, NULL, 1, NULL, NULL, 0, 'bludgeoning', '1d4', 'ranged', 'simple'),
(15, 'Battleaxe', NULL, 4, NULL, 10, NULL, NULL, 0, 'slashing', '1d8', 'melee', 'martial'),
(16, 'Flail', NULL, 2, NULL, 10, NULL, NULL, 0, 'bludgeoning', '1d8', 'melee', 'martial'),
(17, 'Glaive', NULL, 6, NULL, 20, NULL, NULL, 0, 'slashing', '1d10', 'melee', 'martial'),
(18, 'Greataxe', NULL, 7, NULL, 30, NULL, NULL, 0, 'slashing', '1d12', 'melee', 'martial'),
(19, 'Greatsword', NULL, 6, NULL, 50, NULL, NULL, 0, 'slashing', '2d6', 'melee', 'martial'),
(20, 'Halberd', NULL, 6, NULL, 20, NULL, NULL, 0, 'slashing', '1d10', 'melee', 'martial'),
(21, 'Lance', NULL, 6, NULL, 10, NULL, NULL, 0, 'piercing', '1d12', 'melee', 'martial'),
(22, 'Longsword', NULL, 3, NULL, 15, NULL, NULL, 0, 'slashing', '1d8', 'melee', 'martial'),
(23, 'Maul', NULL, 10, NULL, 10, NULL, NULL, 0, 'bludgeoning', '2d6', 'melee', 'martial'),
(24, 'Morningstar', NULL, 4, NULL, 15, NULL, NULL, 0, 'piercing', '1d8', 'melee', 'martial'),
(25, 'Pike', NULL, 18, NULL, 5, NULL, NULL, 0, 'piercing', '1d10', 'melee', 'martial'),
(26, 'Rapier', NULL, 2, NULL, 25, NULL, NULL, 0, 'piercing', '1d8', 'melee', 'martial'),
(27, 'Scimitar', NULL, 3, NULL, 25, NULL, NULL, 0, 'slashing', '1d6', 'melee', 'martial'),
(28, 'Shortsword', NULL, 2, NULL, 10, NULL, NULL, 0, 'piercing', '1d6', 'melee', 'martial'),
(29, 'Trident', NULL, 4, NULL, 5, NULL, NULL, 0, 'piercing', '1d6', 'melee', 'martial'),
(30, 'War Pick', NULL, 2, NULL, 5, NULL, NULL, 0, 'piercing', '1d8', 'melee', 'martial'),
(31, 'Warhammer', NULL, 2, NULL, 15, NULL, NULL, 0, 'bludgeoning', '1d8', 'melee', 'martial'),
(32, 'Whip', NULL, 3, NULL, 2, NULL, NULL, 0, 'slashing', '1d4', 'melee', 'martial'),
(33, 'Blowgun', 'range(25/100)', 1, NULL, 10, NULL, NULL, 0, 'piercing', '1', 'ranged', 'martial'),
(34, 'Crossbow, hand', 'range(30/120)', 3, NULL, 75, NULL, NULL, 0, 'piercing', '1d6', 'ranged', 'martial'),
(35, 'Crossbow, heavy', 'range(100/400)', 18, NULL, 50, NULL, NULL, 0, 'piercing', '1d10', 'ranged', 'martial'),
(36, 'Longbow', 'range(150/600)', 2, NULL, 50, NULL, NULL, 0, 'piercing', '1d8', 'ranged', 'martial'),
(37, 'Net', 'range(5/15)', 3, NULL, 1, NULL, NULL, 0, NULL, NULL, 'ranged', 'martial'),
(38, 'Abacus', NULL, 2, NULL, 2, NULL, NULL, 0, NULL, '', NULL, NULL),
(39, 'Acid (vial)', 'As an action, you can splash the contents of this vial onto a creature within 5 feet of you or throw the vial up to 20 feet, shattering it on impact. In either case, make a ranged attack against a creature or object, treating the acid as an?improvised weapon. On a hit, the target takes 2d6 acid damage.', 1, 1, 25, NULL, NULL, 0, 'acid', '2d6', NULL, NULL),
(40, 'Alchemist?s fire (flask)', 'This sticky, adhesive fluid ignites when exposed to air. As an action, you can throw this flask up to 20 feet, shattering it on impact. On a hit, the target takes 1d4 fire damage at the start of each of its turns. A creature can end this damage by using its action to make a DC 10 Dexterity check to extinguish the flames.', 1, 1, 50, NULL, NULL, 0, NULL, '1d4', NULL, NULL),
(41, 'Blowgun needle', NULL, 0.2, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(42, 'Crossbow bolt', NULL, 0.075, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(43, 'Sling bullet', NULL, 0.075, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(44, 'Antitoxin (vial)', 'A creature that drinks this vial of liquid gains?advantage?on saving throws against poison for 1 hour. It confers no benefit to undead or constructs.', 0, 1, 50, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(45, 'Crystal', NULL, 1, NULL, 10, NULL, NULL, 0, NULL, NULL, 'arcaneFocus', NULL),
(46, 'Orb', NULL, 3, NULL, 20, NULL, NULL, 0, NULL, NULL, 'arcaneFocus', NULL),
(47, 'Rod', NULL, 2, NULL, 10, NULL, NULL, 0, NULL, NULL, 'arcaneFocus', NULL),
(48, 'Staff', NULL, 4, NULL, 5, NULL, NULL, 0, NULL, NULL, 'arcaneFocus', NULL),
(49, 'Wand', NULL, 1, NULL, 10, NULL, NULL, 0, NULL, NULL, 'arcaneFocus', NULL),
(50, 'Backpack', NULL, 5, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(51, 'Ball bearing', NULL, 0.002, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(52, 'Barrel', NULL, 70, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(53, 'Basket', NULL, 2, NULL, NULL, 4, NULL, 0, NULL, NULL, NULL, NULL),
(54, 'Bedroll', NULL, 7, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(55, 'Bell', NULL, 0, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(56, 'Blanket', NULL, 3, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(57, 'Block and tackle', NULL, 5, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(58, 'Book', NULL, 5, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(59, 'Bottle, glass', NULL, 2, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(60, 'Bucket', NULL, 2, NULL, NULL, NULL, 5, 0, NULL, NULL, NULL, NULL),
(61, 'Caltrops (20)', 'Spread a bag of caltrops to cover a square area that is 5 feet on a side. Any creature that enters the area must succeed on a DC 15?Dexterity?saving throw or stop moving this turn and take 1 piercing damage. Taking this damage reduces the creature\'s walking speed by 10 feet until the creature regains at least 1 hit point. A creature moving through the area at half speed doesn\'t need to make the save.', 2, 1, 1, NULL, NULL, 0, 'piercing', '1', NULL, NULL),
(62, 'Candle', NULL, 0, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL),
(63, 'Case, crossbow bolt', NULL, 1, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(64, 'Case, map or scroll', NULL, 1, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(65, 'Chain (10 feet)', NULL, 10, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(66, 'Chalk (1 piece)', NULL, 0, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL),
(67, 'Chest', NULL, 25, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(68, 'Climber?s kit', 'A climber\'s kit includes special pitons, boot tips, gloves, and a harness. You can use the climber\'s kit as an action to anchor yourself; when you do, you can\'t fall more than 25 feet from the point where you anchored yourself, and you can\'t climb more than 25 feet away from that point without undoing the anchor.', 12, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(69, 'Clothes, common', NULL, 3, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(70, 'Clothes, costume', NULL, 4, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(71, 'Clothes, fine', NULL, 6, NULL, 15, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(72, 'Clothes, traveler?s', NULL, 4, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(73, 'Component pouch', NULL, 2, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(74, 'Crowbar', NULL, 5, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(75, 'Sprig of mistletoe', NULL, 0, NULL, 1, NULL, NULL, 0, NULL, NULL, 'druidicFocus', NULL),
(76, 'Totem', NULL, 0, NULL, 1, NULL, NULL, 0, NULL, NULL, 'druidicFocus', NULL),
(77, 'Wooden staff', NULL, 4, NULL, 5, NULL, NULL, 0, NULL, NULL, 'druidicFocus', NULL),
(78, 'Yew wand', NULL, 1, NULL, 10, NULL, NULL, 0, NULL, NULL, 'druidicFocus', NULL),
(79, 'Fishing tackle', NULL, 4, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(80, 'Flask or tankard', NULL, 1, NULL, NULL, NULL, 2, 0, NULL, NULL, NULL, NULL),
(81, 'Grappling hook', NULL, 4, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(82, 'Hammer', NULL, 3, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(83, 'Hammer, sledge', NULL, 10, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(84, 'Healer?s kit', 'This kit is a leather pouch containing bandages, salves, and splints. The kit has ten uses. As an action, you can expend one use of the kit to stabilize a creature that has 0?hit points, without needing to make a?Wisdom?(Medicine) check.', 3, 10, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(85, 'Amulet', NULL, 1, NULL, 5, NULL, NULL, 0, NULL, NULL, 'holySymbol', NULL),
(86, 'Emblem', NULL, 0, NULL, 5, NULL, NULL, 0, NULL, NULL, 'holySymbol', NULL),
(87, 'Reliquary', NULL, 2, NULL, 5, NULL, NULL, 0, NULL, NULL, 'holySymbol', NULL),
(88, 'Holy water (flask)', 'As an action, you can splash the contents of this flask onto a creature within 5 feet of you or throw it up to 20 feet, shattering it on impact. If the target is a fiend or undead, it takes 2d6 radiant damage.', 1, 1, 25, NULL, NULL, 0, 'radiant', '2d6', NULL, NULL),
(89, 'Hourglass', NULL, 1, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(90, 'Hunting trap', 'A creature that steps on the plate must succeed on a DC 13?Dexterity?saving throw or take 1d4 piercing damage and stop moving. Thereafter, until the creature breaks free of the trap, its movement is limited by the length of the chain (typically 3 feet long). A creature can use its action to make a DC 13?Strength?check, freeing itself or another creature within its reach on a success. Each failed check deals 1 piercing damage to the trapped creature.', 25, NULL, 5, NULL, NULL, 0, 'piercing', '1d4', NULL, NULL),
(91, 'Ink (1 ounce bottle)', NULL, 0, 1, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(92, 'Ink pen', NULL, 0, NULL, NULL, NULL, 2, 0, NULL, NULL, NULL, NULL),
(93, 'Jug or pitcher', NULL, 4, NULL, NULL, NULL, 2, 0, NULL, NULL, NULL, NULL),
(94, 'Ladder (10-foot)', NULL, 25, NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, NULL),
(95, 'Lamp', 'A lamp casts bright light in a 15-foot radius and dim light for an additional 30 feet. Once lit, it burns for 6 hours on a flask (1 pint) of oil.', 1, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(96, 'Lantern, bullseye', NULL, 2, NULL, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(97, 'Lantern, hooded', NULL, 2, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(98, 'Lock', 'Includes key.', 1, 1, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(99, 'Magnifying glass', NULL, 0, NULL, 100, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(100, 'Manacles', NULL, 6, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(101, 'Mess kit', 'This tin box contains a cup and simple cutlery. The box clamps together, and one side can be used as a cooking pan and the other as a plate or shallow bowl.', 1, NULL, NULL, 2, NULL, 0, NULL, NULL, NULL, NULL),
(102, 'Mirror, steel', NULL, 0.5, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(103, 'Oil (flask)', 'As an action, you can splash the oil in this flask onto a creature within 5 feet of you or throw it up to 20 feet, shattering it on impact. On a hit, the target is covered in oil. If the target takes any fire damage before the oil dries (after 1 minute), the target takes an additional 5 fire damage from the burning oil. You can also pour a flask of oil on the ground to cover a 5-foot-square area, provided that the surface is level. If lit, the oil burns for 2 rounds and deals 5 fire damage to any creature that enters the area or ends its turn in the area. A creature can take this damage only once per turn.', 1, 1, NULL, 1, NULL, 0, 'fire', '5', NULL, NULL),
(104, 'Paper (one sheet)', NULL, 0, 1, NULL, 2, NULL, 0, NULL, NULL, NULL, NULL),
(105, 'Parchment (one sheet)', NULL, 0, 1, NULL, 1, NULL, 0, NULL, NULL, NULL, NULL),
(106, 'Perfume (vial)', NULL, 0, 1, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(107, 'Pick, miner?s', NULL, 10, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(108, 'Piton', NULL, 0.25, NULL, NULL, NULL, 5, 0, NULL, NULL, NULL, NULL),
(109, 'Poison, basic (vial)', 'You can use the poison in this vial to coat one slashing or piercing weapon or up to three pieces of ammunition. Applying the poison takes an action. A creature hit by the poisoned weapon or ammunition must make a DC 10?Constitution?saving throw or take 1d4 poison damage. Once applied, the poison retains potency for 1 minute before drying.', 0, 1, 100, 0, 0, 0, 'poison', '1d4', NULL, NULL),
(110, 'Pole (10-foot)', NULL, 7, NULL, NULL, NULL, 5, 0, NULL, NULL, NULL, NULL),
(111, 'Pot, iron', NULL, 10, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(112, 'Potion of healing', 'Drinking or administering a potion takes an action.', 0.5, 1, 50, NULL, NULL, 0, 'healing', '2d4+2', NULL, NULL),
(113, 'Pouch', NULL, 1, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(114, 'Quiver', 'Can hold up to 20 arrows.', 1, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(115, 'Ram, portable', 'You can use a portable ram to break down doors. When doing so, you gain a +4 bonus on the Strength check. One other character can help you use the ram, giving you advantage on this check.', 35, NULL, 4, NULL, NULL, 0, 'strength', '4', NULL, NULL),
(116, 'Rations (1 day)', NULL, 2, 1, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(117, 'Robes', NULL, 4, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(118, 'Rope, hempen (50 feet)', NULL, 10, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(119, 'Rope, silk (50 feet)', NULL, 5, NULL, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(120, 'Sack', NULL, 0.5, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL),
(121, 'Scale, merchant?s', NULL, 3, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(122, 'Sealing wax', NULL, 0, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(123, 'Shovel', NULL, 5, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(124, 'Signal whistle', NULL, 0, NULL, NULL, NULL, 5, 0, NULL, NULL, NULL, NULL),
(125, 'Signet ring', NULL, 0, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(126, 'Soap', NULL, 0, 1, NULL, NULL, 2, 0, NULL, NULL, NULL, NULL),
(127, 'Spellbook', NULL, 3, NULL, 50, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(128, 'Spike, iron', NULL, 0.2, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(129, 'Spyglass', 'Objects viewed are magnified to twice their size.', 1, NULL, 1000, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(130, 'Tent, two-person', NULL, 20, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(131, 'Tinderbox', 'Using it to light a torch, or anything else with abundant, exposed fuel, takes an action. Lighting any other fire takes 1 minute.', 1, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(132, 'Torch', 'Burns for 1 hour, providing bright light in a 20-foot radius and dim light for an additional 20 feet. If you make a melee attack with a burning torch and hit, it deals 1 fire damage.', 1, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL),
(133, 'Vial', NULL, 0, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(134, 'Waterskin', NULL, 5, NULL, NULL, 2, NULL, 0, NULL, NULL, NULL, NULL),
(135, 'Whetstone', NULL, 1, NULL, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL),
(136, 'Bagpipes', NULL, 6, NULL, 30, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(137, 'Drum', NULL, 3, NULL, 6, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(138, 'Dulcimer', NULL, 10, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(139, 'Flute', NULL, 1, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(140, 'Lute', NULL, 2, NULL, 35, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(141, 'Lyre', NULL, 2, NULL, 30, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(142, 'Horn', NULL, 2, NULL, 3, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(143, 'Pan flute', NULL, 2, NULL, 12, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(144, 'Shawm', NULL, 1, NULL, 2, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(145, 'Viol', NULL, 1, NULL, 30, NULL, NULL, 0, NULL, NULL, NULL, 'instrume'),
(146, 'Alchemist supplies', NULL, 8, NULL, 50, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(147, 'Brewer supplies', NULL, 9, NULL, 20, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(148, 'Calligrapher supplies', NULL, 5, NULL, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(149, 'Carpenter tools', NULL, 6, NULL, 8, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(150, 'Cartographer tools', NULL, 6, NULL, 15, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(151, 'Cobbler tools', NULL, 5, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(152, 'Cook utensils', NULL, 8, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(153, 'Glassblower tools', NULL, 5, NULL, 30, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(154, 'Jeweler tools', NULL, 2, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(155, 'Leatherworker tools', NULL, 5, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(156, 'Mason tools', NULL, 8, NULL, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(157, 'Painter supplies', NULL, 5, NULL, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(158, 'Potter tools', NULL, 3, NULL, 10, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(159, 'Smith tools', NULL, 8, NULL, 20, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(160, 'Tinker tools', NULL, 10, NULL, 50, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(161, 'Weaver tools', NULL, 5, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(162, 'Woodcarver tools', NULL, 5, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(163, 'Disguise kit', 'Cosmetics, hair dye, and small props that let you create disguises that change your physical appearance. Proficiency with this kit lets you add your proficiency bonus to any ability checks you make to create a visual disguise.', 3, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(164, 'Forgery kit', 'This small box contains a variety of papers and parchments, pens and inks, seals and sealing wax, gold and silver leaf, and other supplies necessary to create convincing forgeries of physical documents. Proficiency with this kit lets you add your proficiency bonus to any ability checks you make to create a physical forgery of a document.', 5, NULL, 15, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(165, 'Dice set', NULL, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, NULL),
(166, 'Playing card set', NULL, 0, NULL, NULL, 5, NULL, 0, NULL, NULL, NULL, NULL),
(167, 'Herbalism kit', 'This kit contains a variety of instruments such as clippers, mortar and pestle, and pouches and vials used by herbalists to create remedies and potions. Proficiency with this kit lets you add your proficiency bonus to any ability checks you make to identify or apply herbs. Also, proficiency with this kit is required to create antitoxin and?potions of healing.', 3, NULL, 5, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(168, 'Navigator?s tools', 'Used for navigation at sea. Proficiency with navigator?s tools lets you chart a ship?s course and follow navigation charts. In addition, these tools allow you to add your proficiency bonus to any ability check you make to avoid getting lost at sea.', 2, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(169, 'Poisoner?s kit', 'Includes the vials, chemicals, and other equipment necessary for the creation of poisons. Proficiency with this kit lets you add your proficiency bonus to any ability checks you make to craft or use poisons.', 2, NULL, 50, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(170, 'Thieves? tools', 'Includes a small file, a set of lock picks, a small mirror mounted on a metal handle, a set of narrow-bladed scissors, and a pair of pliers. Proficiency with these tools lets you add your proficiency bonus to any ability checks you make to disarm traps or open locks.', 1, NULL, 25, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(171, 'Padded Armor', 'Disadvantage on Stealth', 8, NULL, 5, NULL, NULL, 0, 'ac', '11', 'light', 'armor'),
(172, 'Leather Armor', NULL, 10, NULL, 10, NULL, NULL, 0, 'ac', '11', 'light', 'armor'),
(173, 'Studded Leather Armor', NULL, 12, NULL, 45, NULL, NULL, 0, 'ac', '12', 'light', 'armor'),
(174, 'Hide', NULL, 12, NULL, 10, NULL, NULL, 0, 'ac', '12', 'medium', 'armor'),
(175, 'Chain shirt', NULL, 20, NULL, 50, NULL, NULL, 0, 'ac', '13', 'medium', 'armor'),
(176, 'Scale mail', 'Disadvantage on Stealth', 45, NULL, 50, NULL, NULL, 0, 'ac', '14', 'medium', 'armor'),
(177, 'Breastplate', NULL, 20, NULL, 400, NULL, NULL, 0, 'ac', '14', 'medium', 'armor'),
(178, 'Half plate', 'Disadvantage on Stealth', 40, NULL, 750, NULL, NULL, 0, 'ac', '15', 'medium', 'armor'),
(179, 'Ring mail', 'Disadvantage on Stealth', 40, NULL, 30, NULL, NULL, 0, 'ac', '14', 'heavy', 'armor'),
(180, 'Chain mail', 'Disadvantage on Stealth', 55, NULL, 75, NULL, NULL, 0, 'ac', '16', 'heavy', 'armor'),
(181, 'Splint', 'Disadvantage on Stealth', 60, NULL, 200, NULL, NULL, 0, 'ac', '17', 'heavy', 'armor'),
(182, 'Plate', 'Disadvantage on Stealth', 65, NULL, 1, NULL, NULL, 0, 'ac', '18', 'heavy', 'armor'),
(183, 'Shield', '', 6, NULL, 10, NULL, NULL, 0, 'ac', '2', '', 'armor'),
(184, 'Throwing Hammer', 'Thrown (60/120)', 4, 0, 15, 0, 0, 0, 'bludgeoning', '1d6', 'melee', 'martial');

-- --------------------------------------------------------

--
-- Table structure for table `Races`
--

CREATE TABLE `Races` (
  `raceID` int(11) NOT NULL,
  `raceName` varchar(20) NOT NULL,
  `dexMod` int(11) NOT NULL DEFAULT '0',
  `strMod` int(11) NOT NULL DEFAULT '0',
  `conMod` int(11) NOT NULL DEFAULT '0',
  `intMod` int(11) NOT NULL DEFAULT '0',
  `wisMod` int(11) NOT NULL DEFAULT '0',
  `chaMod` int(11) NOT NULL DEFAULT '0',
  `speed` int(11) NOT NULL,
  `otherProf` text,
  `languages` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Races`
--

INSERT INTO `Races` (`raceID`, `raceName`, `dexMod`, `strMod`, `conMod`, `intMod`, `wisMod`, `chaMod`, `speed`, `otherProf`, `languages`) VALUES
(1, 'Dragonborn', 0, 2, 0, 0, 0, 1, 30, '', ''),
(2, 'Hill Dwarf', 0, 0, 2, 0, 1, 0, 25, '', ''),
(3, 'Mountain Dwarf', 0, 2, 2, 0, 0, 0, 25, NULL, ''),
(4, 'High Elf', 2, 0, 0, 1, 0, 0, 30, NULL, ''),
(5, 'Wood Elf', 2, 0, 0, 0, 1, 0, 35, NULL, ''),
(6, 'Dark Elf', 2, 0, 0, 0, 0, 1, 30, NULL, ''),
(7, 'Forest Gnome', 1, 0, 0, 2, 0, 0, 25, NULL, ''),
(8, 'Rock Gnome', 0, 0, 1, 2, 0, 0, 25, NULL, ''),
(9, 'Half-Elf', 0, 0, 0, 0, 0, 2, 30, NULL, ''),
(10, 'Lightfoot Halfling', 2, 0, 0, 0, 0, 1, 25, NULL, ''),
(11, 'Stout Halfling', 2, 0, 1, 0, 0, 0, 25, NULL, ''),
(12, 'Half Orc', 0, 2, 1, 0, 0, 0, 30, NULL, ''),
(13, 'Human', 1, 1, 1, 1, 1, 1, 30, NULL, ''),
(14, 'Tiefling', 0, 0, 0, 1, 0, 2, 30, NULL, 'Common, Infernal');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `userID` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`userID`, `username`, `password`, `email`) VALUES
(114, 'newuser123', 'fc12db72f72e6a3d3f0de85b4cdc698319069f2cacbf8b431a31938660fba003', 'newuser123'),
(115, 'newuser', '11507a0e2f5e69d5dfa40a62a1bd7b6ee57e6bcd85c67c9b8431b36fff21c437', 'newuser'),
(116, 'test', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'test'),
(117, 'Popcorn', '87a0acaec00fa34a3166f0b62b7352868c16752bf796a6af3baf0362c62361ed', 'apple'),
(118, 'fern', 'f0a5da17e0ffa3a21c2b07c964d465799eb0deb62905ccb1b271ce7716614746', 'fern'),
(119, '', '', ''),
(120, 'justATest', 'justATest', 'justATest'),
(121, 'MissVanjie', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'MissVanjie@contact.you'),
(123, 'tesAgaint', 'test', 'test'),
(124, 'johnab', '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', 'john'),
(125, 'sample', 'af2bdbe1aa9b6ec1e2ade1d694f41fc71a831d0268e9891562113d8a62add1bf', 'sample'),
(126, 'sampl', 'af2bdbe1aa9b6ec1e2ade1d694f41fc71a831d0268e9891562113d8a62add1bf', 'sample'),
(129, 'APPLE', '55562347f437d65829303cf6307e71acf8b84a020989dd218f31586eeafd01a9', 'APPLE'),
(130, 'Dount', '7499aced43869b27f505701e4edc737f0cc346add1240d4ba86fbfa251e0fc35', 'frosted'),
(131, 'a', 'ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb', 'a'),
(132, 'hi', '2be23c585f15e5fd3279d0663036dd9f6e634f4225ef326fc83fb874dbb81a0f', 'bye'),
(133, 'mark', '6201eb4dccc956cc4fa3a78dca0c2888177ec52efd48f125df214f046eb43138', 'mark'),
(134, 'john', '96d9632f363564cc3032521409cf22a852f2032eec099ed5967c0d000cec607a', 'john'),
(135, 'pillow', '2be23c585f15e5fd3279d0663036dd9f6e634f4225ef326fc83fb874dbb81a0f', 'sheets@bed.com'),
(136, 'i', '65c74c15a686187bb6bbf9958f494fc6b80068034a659a9ad44991b08c58f2d2', 'e'),
(137, 'jo', 'c278ec5a69c34aace42773e41b1163e6ce40c906f2a14f807d39d1b2a1c2dff5', 'jo'),
(138, 'susanLong', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'sclong1017@gmail.com'),
(139, 'susieQ', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'susieQ@gmail.com'),
(140, 'q', '8e35c2cd3bf6641bdb0e2050b76932cbb2e6034a0ddacc1d9bea82a6ba57f7cf', 'q'),
(141, 'p', '148de9c5a7a44d19e56cd9ae1a554bf67847afb0c58f6e12fa29ac7ddfca9940', 'p'),
(144, 'w', '50e721e49c013f00c62cf59f2163542a9d8df02464efeb615d31051b0fddc326', 'w'),
(145, 'z', '594e519ae499312b29433b7dd8a97ff068defcba9755b6d5d00e84c524d67b06', 'z'),
(146, 'l', 'acac86c0e609ca906f632b0e2dacccb2b77d22b0621f20ebece1a4835b93f6f0', 'l'),
(147, 'bob', '81b637d8fcd2c6da6359e6963113a1170de795e4b725b84d1e0b4cfd9ec58ce9', 'bob');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Abilities`
--
ALTER TABLE `Abilities`
  ADD PRIMARY KEY (`abilityID`);

--
-- Indexes for table `Campaign`
--
ALTER TABLE `Campaign`
  ADD PRIMARY KEY (`campaignID`),
  ADD UNIQUE KEY `partyKey` (`partyKey`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `CharacterAbilities`
--
ALTER TABLE `CharacterAbilities`
  ADD UNIQUE KEY `characterID` (`characterID`,`abilityID`),
  ADD KEY `fkabilityID` (`abilityID`);

--
-- Indexes for table `CharacterItems`
--
ALTER TABLE `CharacterItems`
  ADD UNIQUE KEY `characterID_2` (`characterID`,`itemID`),
  ADD KEY `characterID` (`characterID`),
  ADD KEY `fkitemsID` (`itemID`);

--
-- Indexes for table `Characters`
--
ALTER TABLE `Characters`
  ADD PRIMARY KEY (`characterID`),
  ADD KEY `raceID` (`raceID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `classID` (`classID`);

--
-- Indexes for table `CharactersCampaign`
--
ALTER TABLE `CharactersCampaign`
  ADD UNIQUE KEY `fkCharacterCampaign` (`campaignID`,`characterID`),
  ADD KEY `fkcharacterID3` (`characterID`);

--
-- Indexes for table `Classes`
--
ALTER TABLE `Classes`
  ADD PRIMARY KEY (`classID`);

--
-- Indexes for table `Enemies`
--
ALTER TABLE `Enemies`
  ADD PRIMARY KEY (`enemiesID`);

--
-- Indexes for table `Friends`
--
ALTER TABLE `Friends`
  ADD PRIMARY KEY (`userID`,`friendID`),
  ADD KEY `fkFriendID` (`friendID`);

--
-- Indexes for table `Items`
--
ALTER TABLE `Items`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `Races`
--
ALTER TABLE `Races`
  ADD PRIMARY KEY (`raceID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Abilities`
--
ALTER TABLE `Abilities`
  MODIFY `abilityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;

--
-- AUTO_INCREMENT for table `Campaign`
--
ALTER TABLE `Campaign`
  MODIFY `campaignID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=852;

--
-- AUTO_INCREMENT for table `Characters`
--
ALTER TABLE `Characters`
  MODIFY `characterID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `Classes`
--
ALTER TABLE `Classes`
  MODIFY `classID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `Enemies`
--
ALTER TABLE `Enemies`
  MODIFY `enemiesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Items`
--
ALTER TABLE `Items`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT for table `Races`
--
ALTER TABLE `Races`
  MODIFY `raceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Campaign`
--
ALTER TABLE `Campaign`
  ADD CONSTRAINT `fkDM` FOREIGN KEY (`userID`) REFERENCES `Users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `CharacterAbilities`
--
ALTER TABLE `CharacterAbilities`
  ADD CONSTRAINT `fkabilityID` FOREIGN KEY (`abilityID`) REFERENCES `Abilities` (`abilityID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkcharacterID` FOREIGN KEY (`characterID`) REFERENCES `Characters` (`characterID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `CharacterItems`
--
ALTER TABLE `CharacterItems`
  ADD CONSTRAINT `fkCharacterID2` FOREIGN KEY (`characterID`) REFERENCES `Characters` (`characterID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkitemsID` FOREIGN KEY (`itemID`) REFERENCES `Items` (`itemID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Characters`
--
ALTER TABLE `Characters`
  ADD CONSTRAINT `fkclassID` FOREIGN KEY (`classID`) REFERENCES `Classes` (`classID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fkraceID` FOREIGN KEY (`raceID`) REFERENCES `Races` (`raceID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fkuserID` FOREIGN KEY (`userID`) REFERENCES `Users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `CharactersCampaign`
--
ALTER TABLE `CharactersCampaign`
  ADD CONSTRAINT `fkcampaignID` FOREIGN KEY (`campaignID`) REFERENCES `Campaign` (`campaignID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkcharacterID3` FOREIGN KEY (`characterID`) REFERENCES `Characters` (`characterID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
